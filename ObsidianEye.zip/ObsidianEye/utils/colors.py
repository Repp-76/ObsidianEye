"""Central color palette so the whole UI stays consistent instead of every
module picking its own rich markup."""

BANNER = "bold #7dd3fc"
ACCENT = "#7dd3fc"
MUTED = "#5c6773"
TEXT = "#d6deeb"

OK = "#8be9a1"
WARN = "#f0c674"
ERROR = "#f07178"

SEV_CRITICAL = "bold #ff5c5c"
SEV_HIGH = "#ff8c5c"
SEV_MEDIUM = "#f0c674"
SEV_LOW = "#7dd3fc"
SEV_INFO = "#8595a8"
SEV_POTENTIAL = "#c792ea"

SEVERITY_COLORS = {
    "CRITICAL": SEV_CRITICAL,
    "HIGH": SEV_HIGH,
    "MEDIUM": SEV_MEDIUM,
    "LOW": SEV_LOW,
    "INFO": SEV_INFO,
    "POTENTIAL": SEV_POTENTIAL,
}
