import time
from datetime import datetime, timezone
from urllib.parse import urljoin, urlparse


def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def stamp_for_filename() -> str:
    return datetime.now().strftime("%Y-%m-%d_%H%M%S")


def same_origin(a: str, b: str) -> bool:
    pa, pb = urlparse(a), urlparse(b)
    return (pa.scheme, pa.hostname, pa.port or (443 if pa.scheme == "https" else 80)) == \
           (pb.scheme, pb.hostname, pb.port or (443 if pb.scheme == "https" else 80))


def absolute(base: str, link: str) -> str:
    return urljoin(base, link)


def format_seconds(secs: float) -> str:
    m, s = divmod(int(secs), 60)
    return f"{m}m {s}s" if m else f"{s}s"


def elapsed(start: float) -> str:
    return format_seconds(time.time() - start)
