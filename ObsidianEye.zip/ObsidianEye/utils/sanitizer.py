import re

SECRET_PATTERNS = [
    re.compile(r"AKIA[0-9A-Z]{16}"),                          # AWS key id
    re.compile(r"AIza[0-9A-Za-z\-_]{35}"),                    # Google API key
    re.compile(r"sk_live_[0-9a-zA-Z]{16,}"),                  # Stripe secret
    re.compile(r"ghp_[0-9A-Za-z]{36}"),                       # GitHub token
    re.compile(r"eyJ[0-9A-Za-z_\-]+\.[0-9A-Za-z_\-]+\.[0-9A-Za-z_\-]+"),  # JWT
    re.compile(r"-----BEGIN (RSA |EC )?PRIVATE KEY-----"),
]


def redact_value(value: str, keep: int = 3) -> str:
    if value is None:
        return value
    value = str(value)
    if len(value) <= keep * 2:
        return "*" * len(value)
    return f"{value[:keep]}...{'*' * 6}...{value[-keep:]}"


def find_secret_hits(text: str):
    hits = []
    for pattern in SECRET_PATTERNS:
        for match in pattern.finditer(text or ""):
            hits.append(redact_value(match.group(0)))
    return hits
