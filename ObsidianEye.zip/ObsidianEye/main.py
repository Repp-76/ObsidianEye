import os
import platform
import sys
import time

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.live import Live
from rich.prompt import Prompt

from config.loader import load_config, telegram_configured, config_status_lines
from core.engine import ScanEngine, PROFILES
from core.reporter import build_report, save_report
from core.telegram import send_report, build_findings_text
from utils import colors
from utils.helpers import now_iso, elapsed, format_seconds
from utils.validators import normalize_target, is_valid_hostname, split_target

console = Console()

VERSION = "1.0.0"

BANNER = r"""
   ____  _         _     _ _             ______           
  / __ \| |       (_)   | (_)           |  ____|          
 | |  | | |__  ___ _  __| |_  __ _ _ __ | |__   _   _  ___ 
 | |  | | '_ \/ __| |/ _` | |/ _` | '_ \|  __| | | | |/ _ \
 | |__| | |_) \__ \ | (_| | | (_| | | | | |____| |_| |  __/
  \____/|_.__/|___/_|\__,_|_|\__,_|_| |_|______|\__, |\___|
                                                  __/ |     
     Advanced Web Security Intelligence Auditor |___/      
"""


def clear():
    os.system("cls" if os.name == "nt" else "clear")


def show_startup(cfg, cfg_info):
    clear()
    console.print(BANNER, style=colors.BANNER)
    console.print(f"  Developer: [bold]Repp76[/bold]      Version: {VERSION}      Platform: {platform.system()} {platform.release()}",
                   style=colors.MUTED)
    total_modules = len(PROFILES["FULL"])
    console.print(f"  Scanner engine: modular / plugin-based    Categories loaded: {total_modules}", style=colors.MUTED)
    console.print(
        Panel(
            "ObsidianEye performs safe, non-destructive checks only: no brute forcing, no DoS, "
            "no data exfiltration. Every risky attack class is audited as a security CONTROL "
            "instead of being attempted. Use only against targets you own or are authorized to test.",
            title="Safe-Audit Notice", border_style=colors.WARN, expand=False,
        )
    )
    level_style = {"ok": colors.OK, "warn": colors.WARN, "error": colors.ERROR}
    for level, text in config_status_lines(cfg, cfg_info):
        console.print(f"  [{level_style[level]}]{text}[/]")
    console.print()


def prompt_target() -> dict:
    while True:
        raw = Prompt.ask("[bold]Target[/bold] (URL or hostname)")
        try:
            url = normalize_target(raw)
            target = split_target(url)
        except ValueError as exc:
            console.print(f"  [!] {exc}", style=colors.ERROR)
            continue
        if not is_valid_hostname(target["hostname"]):
            console.print("  [!] That doesn't look like a valid hostname.", style=colors.ERROR)
            continue
        return target


def show_target_summary(target: dict):
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_row("Target", target["url"])
    table.add_row("Hostname", target["hostname"])
    table.add_row("Scheme", target["scheme"])
    table.add_row("Port", str(target["port"]))
    console.print(table)
    console.print()


def prompt_profile() -> str:
    console.print("[bold]Scan profile[/bold]")
    console.print("  [1] QUICK SCAN       - recon, headers, TLS, cookies, CORS, fingerprint")
    console.print("  [2] STANDARD SCAN    - QUICK + crawl, forms, auth posture, sessions, CSRF, files, cache")
    console.print("  [3] FULL AUDIT       - STANDARD + injection/SSRF/traversal indicators, brute-force & DoS audits, GraphQL, JS analysis")
    console.print("  [4] CUSTOM           - pick categories yourself")
    choice = Prompt.ask("Select", choices=["1", "2", "3", "4"], default="3")
    if choice == "1":
        return "QUICK"
    if choice == "2":
        return "STANDARD"
    if choice == "3":
        return "FULL"
    return "CUSTOM"


def prompt_custom_modules():
    all_modules = PROFILES["FULL"]
    console.print("[bold]Available categories[/bold]")
    for i, cls in enumerate(all_modules, start=1):
        console.print(f"  [{i:>2}] {cls.name}  [{colors.MUTED}]({cls.category})[/]")
    raw = Prompt.ask("Enter numbers separated by commas (e.g. 1,3,7)")
    picked = []
    for token in raw.split(","):
        token = token.strip()
        if token.isdigit() and 1 <= int(token) <= len(all_modules):
            picked.append(all_modules[int(token) - 1])
    return picked or all_modules[:8]


def run_dashboard(target, profile, module_classes, scan_config):
    state = {"module": "", "category": "", "index": 0, "total": 0, "requests": 0, "findings": 0, "errors": []}
    start = time.time()

    def render():
        table = Table(box=None, show_header=False, padding=(0, 2))
        table.add_row("Target", target["url"])
        table.add_row("Module", f"[{colors.ACCENT}]{state['module']}[/] ({state['index']}/{state['total']})")
        table.add_row("Category", state["category"])
        table.add_row("Requests", str(state["requests"]))
        table.add_row("Findings", str(state["findings"]))
        table.add_row("Elapsed", elapsed(start))
        if state["errors"]:
            table.add_row("Module errors", str(len(state["errors"])))
        return Panel(table, title="ObsidianEye — Scanning", border_style=colors.ACCENT)

    def on_progress(**kw):
        state.update({k: v for k, v in kw.items() if k in state})
        if "error" in kw:
            state["errors"].append(kw["error"])
        live.update(render())

    engine = ScanEngine(target, profile=profile, scan_config=scan_config,
                         on_progress=on_progress, module_classes=module_classes)

    with Live(render(), console=console, refresh_per_second=6) as live:
        result = engine.run()
        live.update(render())

    return result


def show_results(result, target):
    findings = result["findings"]
    counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
    potential = 0
    for f in findings:
        counts[f.severity] += 1
        if f.confidence == "POTENTIAL":
            potential += 1

    console.print()
    console.print(Panel("SCAN COMPLETE", style=colors.OK, expand=False))

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_row("Target", target["url"])
    table.add_row("Duration", format_seconds(result["duration_seconds"]))
    table.add_row("Requests", str(result["request_count"]))
    table.add_row("Pages", str(len(result["shared"].get("crawl", {}).get("pages", []))))
    table.add_row("Endpoints", str(len(result["shared"].get("endpoints", []))))
    console.print(table)
    console.print()

    sev_table = Table(title="Findings", show_header=False, box=None, padding=(0, 2))
    for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
        sev_table.add_row(sev, str(counts[sev]), style=colors.SEVERITY_COLORS[sev])
    sev_table.add_row("POTENTIAL", str(potential), style=colors.SEV_POTENTIAL)
    console.print(sev_table)

    if findings:
        console.print()
        console.print("[bold]Weakness details[/bold]")
        by_sev = {"CRITICAL": [], "HIGH": [], "MEDIUM": [], "LOW": [], "INFO": []}
        for f in findings:
            by_sev[f.severity].append(f)
        for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"):
            items = by_sev[sev]
            if not items:
                continue
            for f in items:
                console.print(f"  [{colors.SEVERITY_COLORS[sev]}]● {sev}[/] [{colors.MUTED}]({f.confidence})[/] {f.title}")
                console.print(f"      {f.description}")
                console.print(f"      [{colors.MUTED}]{f.url}[/]")

    if result["errors"]:
        console.print(f"\n[{colors.WARN}]{len(result['errors'])} module(s) hit an error and were skipped; see the JSON report.[/]")


def main_loop():
    cfg, cfg_info = load_config()
    while True:
        show_startup(cfg, cfg_info)
        target = prompt_target()
        show_target_summary(target)
        profile = prompt_profile()
        module_classes = prompt_custom_modules() if profile == "CUSTOM" else PROFILES[profile]

        started = now_iso()
        t0 = time.time()
        try:
            result = run_dashboard(target, profile, module_classes, cfg["scan"])
        except KeyboardInterrupt:
            console.print("\n[!] Scan interrupted by user.", style=colors.WARN)
            console.print("[+] Cleaning up...")
            console.print("[+] Partial data preserved where possible.")
            console.print("Goodbye.")
            sys.exit(0)

        finished = now_iso()
        duration = elapsed(t0)

        statistics = {
            "finding_counts": {
                s: len([f for f in result["findings"] if f.severity == s])
                for s in ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO")
            },
            "requests_made": result["request_count"],
            "modules_run": len(module_classes),
            "modules_failed": len(result["errors"]),
        }

        report = build_report(
            target=target, profile=profile, started=started, finished=finished, duration=duration,
            scan_data={
                "reconnaissance": result["shared"].get("reconnaissance", {}),
                "dns": result["shared"].get("dns", {}),
                "tls": result["shared"].get("tls", {}),
                "http": result["shared"].get("http", {}),
                "headers": result["shared"].get("headers", {}),
                "cookies": result["shared"].get("cookies", []),
                "technologies": result["shared"].get("technologies", []),
                "endpoints": result["shared"].get("endpoints", []),
                "forms": result["shared"].get("forms", []),
                "apis": result["shared"].get("apis", []),
            },
            findings=result["findings"], correlated=result["correlated"],
            statistics=statistics, errors=result["errors"],
        )
        report_path = save_report(report, target["hostname"])

        show_results(result, target)
        console.print(f"\nJSON report: {report_path}")

        tg_status = "SKIPPED (not configured)"
        if telegram_configured(cfg):
            chunks = build_findings_text(target["url"], result["findings"], statistics)
            tg_result = send_report(cfg["telegram"]["bot_token"], cfg["telegram"]["chat_id"], report_path, chunks)
            tg_status = "SENT" if tg_result["sent"] else f"FAILED ({tg_result['reason']})"
        console.print(f"Telegram: {tg_status}")

        choice = Prompt.ask("\n[Y] Run another scan   [X] Exit", choices=["Y", "X", "y", "x"], default="X")
        if choice.upper() == "X":
            console.print("Goodbye.")
            break


if __name__ == "__main__":
    try:
        main_loop()
    except KeyboardInterrupt:
        console.print("\n[!] Scan interrupted by user.", style=colors.WARN)
        console.print("[+] Cleaning up...")
        console.print("[+] Partial data preserved where possible.")
        console.print("Goodbye.")
        sys.exit(0)
