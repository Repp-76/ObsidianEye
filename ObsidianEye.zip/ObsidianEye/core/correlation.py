RULES = [
    {
        "name": "Weak CSP + reflected input",
        "requires": {"Weak Content-Security-Policy", "Reflected Parameter"},
        "title": "Weak CSP combined with input reflection raises XSS impact",
        "description": (
            "A permissive Content-Security-Policy was found alongside a parameter "
            "that reflects unencoded input. Individually low/medium, together the "
            "CSP would not meaningfully contain a successful XSS."
        ),
        "severity": "MEDIUM",
        "confidence": "MEDIUM",
    },
    {
        "name": "Missing HSTS + mixed content",
        "requires": {"Missing HSTS Header", "Mixed Content Detected"},
        "title": "Missing HSTS combined with mixed content",
        "description": (
            "The site does not enforce HSTS and also loads resources over plain "
            "HTTP, which together make protocol-downgrade / MITM tampering easier."
        ),
        "severity": "MEDIUM",
        "confidence": "MEDIUM",
    },
    {
        "name": "No rate limiting + weak auth error consistency",
        "requires": {"No Rate-Limiting Indicators", "Inconsistent Authentication Errors"},
        "title": "Missing rate limiting combined with username enumeration",
        "description": (
            "No throttling indicators were observed on the authentication endpoint, "
            "and login responses differ for valid vs invalid usernames, making "
            "automated enumeration and credential testing considerably easier."
        ),
        "severity": "HIGH",
        "confidence": "MEDIUM",
    },
]


def correlate(findings):
    titles = {f.title for f in findings}
    correlated = []
    for rule in RULES:
        if rule["requires"].issubset(titles):
            correlated.append({
                "rule": rule["name"],
                "title": rule["title"],
                "description": rule["description"],
                "severity": rule["severity"],
                "confidence": rule["confidence"],
                "based_on": sorted(rule["requires"]),
            })
    return correlated
