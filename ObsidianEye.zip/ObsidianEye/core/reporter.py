import json
import os

from utils.helpers import stamp_for_filename

REPORTS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "reports")


def build_report(*, target, profile, started, finished, duration, scan_data,
                  findings, correlated, statistics, errors) -> dict:
    counts = statistics.get("finding_counts", {})
    return {
        "tool": {"name": "ObsidianEye", "version": "1.0.0", "developer": "Repp76"},
        "scan": {
            "profile": profile,
            "started": started,
            "finished": finished,
            "duration": duration,
        },
        "target": target,
        "summary": {
            "total_findings": len(findings),
            "by_severity": counts,
            "correlated_observations": len(correlated),
        },
        "reconnaissance": scan_data.get("reconnaissance", {}),
        "dns": scan_data.get("dns", {}),
        "tls": scan_data.get("tls", {}),
        "http": scan_data.get("http", {}),
        "headers": scan_data.get("headers", {}),
        "cookies": scan_data.get("cookies", []),
        "technologies": scan_data.get("technologies", []),
        "endpoints": scan_data.get("endpoints", []),
        "forms": scan_data.get("forms", []),
        "apis": scan_data.get("apis", []),
        "findings": [f.to_dict() for f in findings],
        "correlated_observations": correlated,
        "recommendations": sorted({f.recommendation for f in findings if f.recommendation}),
        "statistics": statistics,
        "errors": errors,
    }


def save_report(report: dict, hostname: str) -> str:
    os.makedirs(REPORTS_DIR, exist_ok=True)
    filename = f"{hostname}_{stamp_for_filename()}.json"
    path = os.path.join(REPORTS_DIR, filename)
    text = json.dumps(report, indent=2, ensure_ascii=False)
    json.loads(text)  # validate before touching disk
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)
    return path
