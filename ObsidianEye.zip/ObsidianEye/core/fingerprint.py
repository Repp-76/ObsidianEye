import re

# (technology, category, pattern-list) — kept flat and data-driven so new
# signatures are just another tuple, not a new code path.
SIGNATURES = [
    ("WordPress", "cms", [r"wp-content", r"wp-includes", r"/wp-json/"]),
    ("Drupal", "cms", [r"Drupal\.settings", r"/sites/default/files", r"X-Drupal-Cache"]),
    ("Joomla", "cms", [r"/media/jui/", r"Joomla!"]),
    ("Shopify", "cms", [r"cdn\.shopify\.com", r"Shopify\.theme"]),
    ("Magento", "cms", [r"Mage\.Cookies", r"/static/version"]),
    ("Next.js", "frontend", [r"__NEXT_DATA__", r"/_next/static"]),
    ("Nuxt.js", "frontend", [r"__NUXT__", r"/_nuxt/"]),
    ("React", "frontend", [r"data-reactroot", r"react-dom"]),
    ("Vue.js", "frontend", [r"data-v-[a-f0-9]{6,}", r"__vue__"]),
    ("Angular", "frontend", [r"ng-version", r"\[ng-"]),
    ("jQuery", "library", [r"jquery(\.min)?\.js"]),
    ("Bootstrap", "library", [r"bootstrap(\.min)?\.css", r"bootstrap(\.min)?\.js"]),
    ("Laravel", "backend", [r"laravel_session", r"XSRF-TOKEN"]),
    ("Django", "backend", [r"csrftoken", r"__admin_media_prefix__"]),
    ("Express", "backend", [r"X-Powered-By: *Express"]),
    ("ASP.NET", "backend", [r"__VIEWSTATE", r"X-AspNet-Version", r"\.aspx"]),
    ("PHP", "language", [r"X-Powered-By: *PHP", r"PHPSESSID"]),
    ("Cloudflare", "cdn_waf", [r"cloudflare", r"__cfduid", r"cf-ray"]),
    ("Akamai", "cdn_waf", [r"akamai"]),
    ("AWS CloudFront", "cdn_waf", [r"cloudfront"]),
    ("Sucuri WAF", "cdn_waf", [r"sucuri"]),
    ("Nginx", "server", [r"nginx"]),
    ("Apache", "server", [r"apache"]),
    ("IIS", "server", [r"microsoft-iis"]),
]


def fingerprint(headers: dict, html: str, cookie_names) -> list:
    haystacks = " ".join([
        " ".join(f"{k}: {v}" for k, v in headers.items()),
        html or "",
        " ".join(cookie_names or []),
    ])
    hits = []
    for name, category, patterns in SIGNATURES:
        for pattern in patterns:
            if re.search(pattern, haystacks, re.IGNORECASE):
                hits.append({"technology": name, "category": category})
                break
    return hits
