from dataclasses import dataclass, field, asdict
from itertools import count
from utils.helpers import now_iso

SEVERITIES = ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO")
CONFIDENCES = ("CONFIRMED", "HIGH", "MEDIUM", "LOW", "POTENTIAL")

_id_counter = count(1)


@dataclass
class Finding:
    title: str
    category: str
    severity: str
    confidence: str
    url: str
    description: str
    evidence: str
    impact: str
    recommendation: str
    module: str
    method: str = "GET"
    parameter: str = ""
    references: list = field(default_factory=list)
    id: str = ""
    timestamp: str = ""

    def __post_init__(self):
        if self.severity not in SEVERITIES:
            raise ValueError(f"bad severity: {self.severity}")
        if self.confidence not in CONFIDENCES:
            raise ValueError(f"bad confidence: {self.confidence}")
        if not self.id:
            self.id = f"OE-{next(_id_counter):04d}"
        if not self.timestamp:
            self.timestamp = now_iso()

    def to_dict(self):
        return asdict(self)


class FindingCollector:
    def __init__(self):
        self._findings = []

    def add(self, **kwargs) -> Finding:
        f = Finding(**kwargs)
        self._findings.append(f)
        return f

    def extend(self, findings):
        self._findings.extend(findings)

    def all(self):
        return list(self._findings)

    def counts(self):
        out = {s: 0 for s in SEVERITIES}
        out["POTENTIAL"] = 0
        for f in self._findings:
            if f.confidence == "POTENTIAL":
                out["POTENTIAL"] += 1
            out[f.severity] += 1
        return out
