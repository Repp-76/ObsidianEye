import time
import requests

DEFAULT_UA = "ObsidianEye/1.0 (+security-audit; contact via target owner)"


class HttpClient:
    """Thin wrapper around requests.Session that backs off on errors/429s
    instead of hammering the target. All modules should go through this
    instead of calling requests directly, so throttling stays global."""

    def __init__(self, timeout=10, delay=0.15, max_retries=2, verify_tls=True):
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": DEFAULT_UA})
        self.timeout = timeout
        self.delay = delay
        self.max_retries = max_retries
        self.verify_tls = verify_tls
        self.request_count = 0
        self.slow_mode = False
        self.seen_urls = set()

    def _sleep(self):
        time.sleep(self.delay * (3 if self.slow_mode else 1))

    def request(self, method, url, allow_redirects=True, **kwargs):
        kwargs.setdefault("timeout", self.timeout)
        kwargs.setdefault("verify", self.verify_tls)
        attempt = 0
        last_exc = None
        while attempt <= self.max_retries:
            try:
                self._sleep()
                resp = self.session.request(
                    method, url, allow_redirects=allow_redirects, **kwargs
                )
                self.request_count += 1
                if resp.status_code == 429:
                    self.slow_mode = True
                    retry_after = resp.headers.get("Retry-After")
                    wait = float(retry_after) if retry_after and retry_after.isdigit() else 2.0
                    time.sleep(min(wait, 5.0))
                    attempt += 1
                    continue
                if resp.status_code >= 500:
                    attempt += 1
                    time.sleep(0.5 * attempt)
                    continue
                return resp
            except requests.RequestException as exc:
                last_exc = exc
                attempt += 1
                time.sleep(0.4 * attempt)
        if last_exc:
            raise last_exc
        return None

    def get(self, url, **kwargs):
        return self.request("GET", url, **kwargs)

    def post(self, url, **kwargs):
        return self.request("POST", url, **kwargs)

    def head(self, url, **kwargs):
        return self.request("HEAD", url, **kwargs)

    def options(self, url, **kwargs):
        return self.request("OPTIONS", url, **kwargs)
