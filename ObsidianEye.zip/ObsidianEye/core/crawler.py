from urllib.parse import urlparse, urldefrag
from bs4 import BeautifulSoup

from utils.helpers import same_origin, absolute

SKIP_EXT = (".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".ico",
            ".woff", ".woff2", ".ttf", ".eot", ".mp4", ".mp3", ".zip", ".pdf")


class Crawler:
    def __init__(self, client, start_url, depth=2, page_limit=60):
        self.client = client
        self.start_url = start_url.rstrip("/")
        self.depth = depth
        self.page_limit = page_limit
        self.visited = set()
        self.pages = []
        self.forms = []
        self.scripts = set()
        self.stylesheets = set()
        self.external_links = set()

    def run(self):
        queue = [(self.start_url, 0)]
        while queue and len(self.visited) < self.page_limit:
            url, depth = queue.pop(0)
            url = urldefrag(url)[0]
            if url in self.visited or depth > self.depth:
                continue
            if url.lower().endswith(SKIP_EXT):
                continue
            self.visited.add(url)

            try:
                resp = self.client.get(url)
            except Exception:
                continue
            if resp is None or "text/html" not in resp.headers.get("Content-Type", ""):
                continue

            page = {
                "url": url,
                "status": resp.status_code,
                "title": None,
                "content_length": len(resp.content),
            }
            self.pages.append(page)

            try:
                soup = BeautifulSoup(resp.text, "html.parser")
                title_tag = soup.find("title")
                page["title"] = title_tag.get_text(strip=True) if title_tag else ""

                self._collect_forms(url, soup)
                self._collect_assets(url, soup)

                if depth < self.depth:
                    for link in self._collect_links(url, soup):
                        if link not in self.visited:
                            queue.append((link, depth + 1))
            except Exception:
                # A malformed page shouldn't stop the rest of the crawl —
                # we already recorded the page itself above.
                continue

        return {
            "pages": self.pages,
            "forms": self.forms,
            "scripts": sorted(self.scripts),
            "stylesheets": sorted(self.stylesheets),
            "external_links": sorted(self.external_links),
        }

    def _collect_links(self, base, soup):
        found = []
        for a in soup.find_all("a", href=True):
            href = a["href"].strip()
            if href.startswith(("mailto:", "tel:", "javascript:", "#")):
                continue
            target = urldefrag(absolute(base, href))[0]
            if same_origin(target, self.start_url):
                found.append(target)
            else:
                self.external_links.add(target)
        return found

    def _collect_assets(self, base, soup):
        for script in soup.find_all("script", src=True):
            self.scripts.add(absolute(base, script["src"]))
        for link in soup.find_all("link", rel=lambda v: v and "stylesheet" in v, href=True):
            self.stylesheets.add(absolute(base, link["href"]))

    def _collect_forms(self, base, soup):
        for form in soup.find_all("form"):
            inputs = []
            for field in form.find_all(["input", "textarea", "select"]):
                inputs.append({
                    "name": field.get("name", ""),
                    "type": field.get("type", field.name),
                    "autocomplete": field.get("autocomplete", ""),
                    "accept": field.get("accept", ""),
                })
            self.forms.append({
                "page": base,
                "action": absolute(base, form.get("action", base)),
                "method": (form.get("method") or "GET").upper(),
                "inputs": inputs,
                "has_csrf_field": any(
                    "csrf" in (i["name"] or "").lower() or "token" in (i["name"] or "").lower()
                    for i in inputs
                ),
            })
