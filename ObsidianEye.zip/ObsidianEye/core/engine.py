import time

from core.http_client import HttpClient
from core.findings import FindingCollector
from core.correlation import correlate
from core.logger import ScanLogger
from modules.base import ScanContext

from modules.recon import ReconModule
from modules.dns_mod import DnsModule
from modules.http_mod import HttpModule
from modules.tls_mod import TlsModule
from modules.headers_mod import HeadersModule
from modules.cookies_mod import CookiesModule
from modules.cors_mod import CorsModule
from modules.crawl_mod import CrawlModule
from modules.fingerprint_mod import FingerprintModule
from modules.securitytxt_mod import SecurityTxtModule
from modules.robots_mod import RobotsSitemapModule
from modules.mixedcontent_mod import MixedContentModule
from modules.sri_mod import SriModule
from modules.auth_mod import AuthModule
from modules.bruteforce_mod import BruteForceProtectionModule
from modules.session_mod import SessionModule
from modules.authz_mod import AuthorizationModule
from modules.injection_mod import InjectionModule
from modules.csrf_mod import CsrfModule
from modules.ssrf_mod import SsrfModule
from modules.traversal_mod import TraversalModule
from modules.redirect_mod import OpenRedirectModule
from modules.upload_mod import UploadSecurityModule
from modules.api_mod import ApiModule
from modules.graphql_mod import GraphQLModule
from modules.websocket_mod import WebSocketModule
from modules.js_mod import JavaScriptModule
from modules.files_mod import SensitiveFilesModule
from modules.directory_listing_mod import DirectoryListingModule
from modules.disclosure_mod import ErrorDisclosureModule
from modules.cache_mod import CacheModule
from modules.dos_mod import DosProtectionModule
from modules.dependency_mod import DependencyExposureModule

# Order matters: recon/headers/cookies/crawl populate ctx.shared that later
# modules (injection, auth, api, etc.) read from.
QUICK_MODULES = [
    ReconModule, DnsModule, HttpModule, TlsModule, HeadersModule,
    CookiesModule, CorsModule, FingerprintModule,
]

STANDARD_MODULES = QUICK_MODULES + [
    CrawlModule, SecurityTxtModule, RobotsSitemapModule, MixedContentModule,
    SriModule, AuthModule, SessionModule, CsrfModule, OpenRedirectModule,
    ApiModule, SensitiveFilesModule, DirectoryListingModule,
    ErrorDisclosureModule, CacheModule,
]

FULL_MODULES = STANDARD_MODULES + [
    BruteForceProtectionModule, AuthorizationModule, InjectionModule,
    SsrfModule, TraversalModule, UploadSecurityModule, GraphQLModule,
    WebSocketModule, JavaScriptModule, DosProtectionModule,
    DependencyExposureModule,
]

PROFILES = {"QUICK": QUICK_MODULES, "STANDARD": STANDARD_MODULES, "FULL": FULL_MODULES}


class ScanEngine:
    def __init__(self, target, profile="FULL", scan_config=None, on_progress=None, module_classes=None):
        self.target = target
        self.profile = profile
        self.scan_config = scan_config or {}
        self.on_progress = on_progress or (lambda **kw: None)
        self.module_classes = module_classes if module_classes is not None else PROFILES.get(profile, FULL_MODULES)

    def run(self):
        client = HttpClient(
            timeout=self.scan_config.get("timeout", 10),
            delay=self.scan_config.get("delay", 0.15),
            max_retries=self.scan_config.get("max_retries", 2),
            verify_tls=self.scan_config.get("verify_tls", True),
        )
        collector = FindingCollector()
        logger = ScanLogger()
        ctx = ScanContext(client=client, target=self.target, collector=collector)

        instances = []
        for cls in self.module_classes:
            if cls is CrawlModule:
                instances.append(cls(
                    depth=self.scan_config.get("crawl_depth", 2),
                    page_limit=self.scan_config.get("crawl_page_limit", 60),
                ))
            else:
                instances.append(cls())

        start = time.time()
        for i, module in enumerate(instances, start=1):
            self.on_progress(
                module=module.name, category=module.category,
                index=i, total=len(instances),
                requests=client.request_count, findings=len(collector.all()),
            )
            try:
                module.scan(ctx)
            except Exception as exc:
                logger.module_failed(module.name, exc)
                self.on_progress(
                    module=module.name, category=module.category,
                    index=i, total=len(instances), error=str(exc),
                    requests=client.request_count, findings=len(collector.all()),
                )

        findings = collector.all()
        correlated = correlate(findings)

        return {
            "shared": ctx.shared,
            "findings": findings,
            "correlated": correlated,
            "errors": logger.to_list(),
            "request_count": client.request_count,
            "duration_seconds": time.time() - start,
        }
