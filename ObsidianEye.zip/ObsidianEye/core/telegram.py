import os
import time
import requests

API_ROOT = "https://api.telegram.org/bot{token}/{method}"
MAX_DOCUMENT_BYTES = 45 * 1024 * 1024  # Telegram's bot API ceiling is ~50MB
MAX_MESSAGE_CHARS = 3800               # stay safely under Telegram's 4096 limit

SEVERITY_ORDER = ("CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO")


def build_findings_text(target_url, findings, statistics):
    """Full weakness rundown for Telegram — not just counts. Grouped by
    severity, each finding gets its title, a trimmed description and the
    affected URL so it reads on its own without opening the JSON."""
    counts = statistics.get("finding_counts", {})
    header = (
        f"ObsidianEye scan complete\n"
        f"Target: {target_url}\n"
        f"Findings: {len(findings)} "
        f"(C:{counts.get('CRITICAL', 0)} H:{counts.get('HIGH', 0)} "
        f"M:{counts.get('MEDIUM', 0)} L:{counts.get('LOW', 0)} I:{counts.get('INFO', 0)})"
    )

    by_sev = {s: [] for s in SEVERITY_ORDER}
    for f in findings:
        by_sev.setdefault(f.severity, []).append(f)

    body_lines = []
    for sev in SEVERITY_ORDER:
        items = by_sev.get(sev, [])
        if not items:
            continue
        body_lines.append(f"\n[{sev}] ({len(items)})")
        for f in items:
            desc = (f.description or "").strip()
            if len(desc) > 140:
                desc = desc[:137] + "..."
            body_lines.append(f"- {f.title} — {desc}\n  {f.url}")

    if not findings:
        body_lines.append("\nNo findings from this scan.")

    full_text = header + "\n" + "\n".join(body_lines)
    return _chunk_text(full_text)


def _chunk_text(text, limit=MAX_MESSAGE_CHARS):
    chunks = []
    while text:
        if len(text) <= limit:
            chunks.append(text)
            break
        split_at = text.rfind("\n", 0, limit)
        if split_at <= 0:
            split_at = limit
        chunks.append(text[:split_at])
        text = text[split_at:]
    return chunks


def send_report(bot_token: str, chat_id: str, report_path: str, findings_text_chunks) -> dict:
    if not bot_token or not chat_id:
        return {"sent": False, "reason": "telegram not configured"}

    try:
        for i, chunk in enumerate(findings_text_chunks):
            resp = requests.post(
                API_ROOT.format(token=bot_token, method="sendMessage"),
                data={"chat_id": chat_id, "text": chunk},
                timeout=15,
            )
            if resp.status_code != 200:
                return {"sent": False, "reason": f"sendMessage failed ({resp.status_code}): {resp.text[:200]}"}
            if i < len(findings_text_chunks) - 1:
                time.sleep(0.3)

        size = os.path.getsize(report_path)
        if size > MAX_DOCUMENT_BYTES:
            return {"sent": True, "reason": "summary sent; JSON report too large to attach"}

        with open(report_path, "rb") as fh:
            doc_resp = requests.post(
                API_ROOT.format(token=bot_token, method="sendDocument"),
                data={"chat_id": chat_id},
                files={"document": fh},
                timeout=30,
            )
        if doc_resp.status_code != 200:
            return {"sent": True, "reason": f"summary sent; JSON attach failed ({doc_resp.status_code}): {doc_resp.text[:200]}"}

        return {"sent": True, "reason": ""}

    except requests.Timeout:
        return {"sent": False, "reason": "timeout contacting Telegram"}
    except requests.RequestException as exc:
        return {"sent": False, "reason": f"network error: {exc}"}
