# -*- coding: utf-8 -*-
# CodeShield Encrypted Python — Powered by Repp76
import base64, sys, os

_cs_dir = os.path.dirname(os.path.abspath(__file__)) if "__file__" in dir() else os.getcwd()
for _cs_p in (_cs_dir, os.getcwd()):
    if _cs_p not in sys.path:
        sys.path.insert(0, _cs_p)

_cs_parts = [
    "aW1wb3J0IG9zCmltcG9ydCB0aW1lCmltcG9ydCByZXF1ZXN0cwoKQVBJX1JPT1QgPSAiaHR0cHM6",
    "Ly9hcGkudGVsZWdyYW0ub3JnL2JvdHt0b2tlbn0ve21ldGhvZH0iCk1BWF9ET0NVTUVOVF9CWVRF",
    "UyA9IDQ1ICogMTAyNCAqIDEwMjQgICMgVGVsZWdyYW0ncyBib3QgQVBJIGNlaWxpbmcgaXMgfjUw",
    "TUIKTUFYX01FU1NBR0VfQ0hBUlMgPSAzODAwICAgICAgICAgICAgICAgIyBzdGF5IHNhZmVseSB1",
    "bmRlciBUZWxlZ3JhbSdzIDQwOTYgbGltaXQKClNFVkVSSVRZX09SREVSID0gKCJDUklUSUNBTCIs",
    "ICJISUdIIiwgIk1FRElVTSIsICJMT1ciLCAiSU5GTyIpCgoKZGVmIGJ1aWxkX2ZpbmRpbmdzX3Rl",
    "eHQodGFyZ2V0X3VybCwgZmluZGluZ3MsIHN0YXRpc3RpY3MpOgogICAgIiIiRnVsbCB3ZWFrbmVz",
    "cyBydW5kb3duIGZvciBUZWxlZ3JhbSDigJQgbm90IGp1c3QgY291bnRzLiBHcm91cGVkIGJ5CiAg",
    "ICBzZXZlcml0eSwgZWFjaCBmaW5kaW5nIGdldHMgaXRzIHRpdGxlLCBhIHRyaW1tZWQgZGVzY3Jp",
    "cHRpb24gYW5kIHRoZQogICAgYWZmZWN0ZWQgVVJMIHNvIGl0IHJlYWRzIG9uIGl0cyBvd24gd2l0",
    "aG91dCBvcGVuaW5nIHRoZSBKU09OLiIiIgogICAgY291bnRzID0gc3RhdGlzdGljcy5nZXQoImZp",
    "bmRpbmdfY291bnRzIiwge30pCiAgICBoZWFkZXIgPSAoCiAgICAgICAgZiJPYnNpZGlhbkV5ZSBz",
    "Y2FuIGNvbXBsZXRlXG4iCiAgICAgICAgZiJUYXJnZXQ6IHt0YXJnZXRfdXJsfVxuIgogICAgICAg",
    "IGYiRmluZGluZ3M6IHtsZW4oZmluZGluZ3MpfSAiCiAgICAgICAgZiIoQzp7Y291bnRzLmdldCgn",
    "Q1JJVElDQUwnLCAwKX0gSDp7Y291bnRzLmdldCgnSElHSCcsIDApfSAiCiAgICAgICAgZiJNOntj",
    "b3VudHMuZ2V0KCdNRURJVU0nLCAwKX0gTDp7Y291bnRzLmdldCgnTE9XJywgMCl9IEk6e2NvdW50",
    "cy5nZXQoJ0lORk8nLCAwKX0pIgogICAgKQoKICAgIGJ5X3NldiA9IHtzOiBbXSBmb3IgcyBpbiBT",
    "RVZFUklUWV9PUkRFUn0KICAgIGZvciBmIGluIGZpbmRpbmdzOgogICAgICAgIGJ5X3Nldi5zZXRk",
    "ZWZhdWx0KGYuc2V2ZXJpdHksIFtdKS5hcHBlbmQoZikKCiAgICBib2R5X2xpbmVzID0gW10KICAg",
    "IGZvciBzZXYgaW4gU0VWRVJJVFlfT1JERVI6CiAgICAgICAgaXRlbXMgPSBieV9zZXYuZ2V0KHNl",
    "diwgW10pCiAgICAgICAgaWYgbm90IGl0ZW1zOgogICAgICAgICAgICBjb250aW51ZQogICAgICAg",
    "IGJvZHlfbGluZXMuYXBwZW5kKGYiXG5be3Nldn1dICh7bGVuKGl0ZW1zKX0pIikKICAgICAgICBm",
    "b3IgZiBpbiBpdGVtczoKICAgICAgICAgICAgZGVzYyA9IChmLmRlc2NyaXB0aW9uIG9yICIiKS5z",
    "dHJpcCgpCiAgICAgICAgICAgIGlmIGxlbihkZXNjKSA+IDE0MDoKICAgICAgICAgICAgICAgIGRl",
    "c2MgPSBkZXNjWzoxMzddICsgIi4uLiIKICAgICAgICAgICAgYm9keV9saW5lcy5hcHBlbmQoZiIt",
    "IHtmLnRpdGxlfSDigJQge2Rlc2N9XG4gIHtmLnVybH0iKQoKICAgIGlmIG5vdCBmaW5kaW5nczoK",
    "ICAgICAgICBib2R5X2xpbmVzLmFwcGVuZCgiXG5ObyBmaW5kaW5ncyBmcm9tIHRoaXMgc2Nhbi4i",
    "KQoKICAgIGZ1bGxfdGV4dCA9IGhlYWRlciArICJcbiIgKyAiXG4iLmpvaW4oYm9keV9saW5lcykK",
    "ICAgIHJldHVybiBfY2h1bmtfdGV4dChmdWxsX3RleHQpCgoKZGVmIF9jaHVua190ZXh0KHRleHQs",
    "IGxpbWl0PU1BWF9NRVNTQUdFX0NIQVJTKToKICAgIGNodW5rcyA9IFtdCiAgICB3aGlsZSB0ZXh0",
    "OgogICAgICAgIGlmIGxlbih0ZXh0KSA8PSBsaW1pdDoKICAgICAgICAgICAgY2h1bmtzLmFwcGVu",
    "ZCh0ZXh0KQogICAgICAgICAgICBicmVhawogICAgICAgIHNwbGl0X2F0ID0gdGV4dC5yZmluZCgi",
    "XG4iLCAwLCBsaW1pdCkKICAgICAgICBpZiBzcGxpdF9hdCA8PSAwOgogICAgICAgICAgICBzcGxp",
    "dF9hdCA9IGxpbWl0CiAgICAgICAgY2h1bmtzLmFwcGVuZCh0ZXh0WzpzcGxpdF9hdF0pCiAgICAg",
    "ICAgdGV4dCA9IHRleHRbc3BsaXRfYXQ6XQogICAgcmV0dXJuIGNodW5rcwoKCmRlZiBzZW5kX3Jl",
    "cG9ydChib3RfdG9rZW46IHN0ciwgY2hhdF9pZDogc3RyLCByZXBvcnRfcGF0aDogc3RyLCBmaW5k",
    "aW5nc190ZXh0X2NodW5rcykgLT4gZGljdDoKICAgIGlmIG5vdCBib3RfdG9rZW4gb3Igbm90IGNo",
    "YXRfaWQ6CiAgICAgICAgcmV0dXJuIHsic2VudCI6IEZhbHNlLCAicmVhc29uIjogInRlbGVncmFt",
    "IG5vdCBjb25maWd1cmVkIn0KCiAgICB0cnk6CiAgICAgICAgZm9yIGksIGNodW5rIGluIGVudW1l",
    "cmF0ZShmaW5kaW5nc190ZXh0X2NodW5rcyk6CiAgICAgICAgICAgIHJlc3AgPSByZXF1ZXN0cy5w",
    "b3N0KAogICAgICAgICAgICAgICAgQVBJX1JPT1QuZm9ybWF0KHRva2VuPWJvdF90b2tlbiwgbWV0",
    "aG9kPSJzZW5kTWVzc2FnZSIpLAogICAgICAgICAgICAgICAgZGF0YT17ImNoYXRfaWQiOiBjaGF0",
    "X2lkLCAidGV4dCI6IGNodW5rfSwKICAgICAgICAgICAgICAgIHRpbWVvdXQ9MTUsCiAgICAgICAg",
    "ICAgICkKICAgICAgICAgICAgaWYgcmVzcC5zdGF0dXNfY29kZSAhPSAyMDA6CiAgICAgICAgICAg",
    "ICAgICByZXR1cm4geyJzZW50IjogRmFsc2UsICJyZWFzb24iOiBmInNlbmRNZXNzYWdlIGZhaWxl",
    "ZCAoe3Jlc3Auc3RhdHVzX2NvZGV9KToge3Jlc3AudGV4dFs6MjAwXX0ifQogICAgICAgICAgICBp",
    "ZiBpIDwgbGVuKGZpbmRpbmdzX3RleHRfY2h1bmtzKSAtIDE6CiAgICAgICAgICAgICAgICB0aW1l",
    "LnNsZWVwKDAuMykKCiAgICAgICAgc2l6ZSA9IG9zLnBhdGguZ2V0c2l6ZShyZXBvcnRfcGF0aCkK",
    "ICAgICAgICBpZiBzaXplID4gTUFYX0RPQ1VNRU5UX0JZVEVTOgogICAgICAgICAgICByZXR1cm4g",
    "eyJzZW50IjogVHJ1ZSwgInJlYXNvbiI6ICJzdW1tYXJ5IHNlbnQ7IEpTT04gcmVwb3J0IHRvbyBs",
    "YXJnZSB0byBhdHRhY2gifQoKICAgICAgICB3aXRoIG9wZW4ocmVwb3J0X3BhdGgsICJyYiIpIGFz",
    "IGZoOgogICAgICAgICAgICBkb2NfcmVzcCA9IHJlcXVlc3RzLnBvc3QoCiAgICAgICAgICAgICAg",
    "ICBBUElfUk9PVC5mb3JtYXQodG9rZW49Ym90X3Rva2VuLCBtZXRob2Q9InNlbmREb2N1bWVudCIp",
    "LAogICAgICAgICAgICAgICAgZGF0YT17ImNoYXRfaWQiOiBjaGF0X2lkfSwKICAgICAgICAgICAg",
    "ICAgIGZpbGVzPXsiZG9jdW1lbnQiOiBmaH0sCiAgICAgICAgICAgICAgICB0aW1lb3V0PTMwLAog",
    "ICAgICAgICAgICApCiAgICAgICAgaWYgZG9jX3Jlc3Auc3RhdHVzX2NvZGUgIT0gMjAwOgogICAg",
    "ICAgICAgICByZXR1cm4geyJzZW50IjogVHJ1ZSwgInJlYXNvbiI6IGYic3VtbWFyeSBzZW50OyBK",
    "U09OIGF0dGFjaCBmYWlsZWQgKHtkb2NfcmVzcC5zdGF0dXNfY29kZX0pOiB7ZG9jX3Jlc3AudGV4",
    "dFs6MjAwXX0ifQoKICAgICAgICByZXR1cm4geyJzZW50IjogVHJ1ZSwgInJlYXNvbiI6ICIifQoK",
    "ICAgIGV4Y2VwdCByZXF1ZXN0cy5UaW1lb3V0OgogICAgICAgIHJldHVybiB7InNlbnQiOiBGYWxz",
    "ZSwgInJlYXNvbiI6ICJ0aW1lb3V0IGNvbnRhY3RpbmcgVGVsZWdyYW0ifQogICAgZXhjZXB0IHJl",
    "cXVlc3RzLlJlcXVlc3RFeGNlcHRpb24gYXMgZXhjOgogICAgICAgIHJldHVybiB7InNlbnQiOiBG",
    "YWxzZSwgInJlYXNvbiI6IGYibmV0d29yayBlcnJvcjoge2V4Y30ifQo="
]
_cs_code = base64.b64decode("".join(_cs_parts)).decode("utf-8")
_cs_file = __file__ if "__file__" in dir() else "<codeshield>"
_cs_compiled = compile(_cs_code, _cs_file, "exec")

# Bersihkan helper vars supaya globals() yang exec() terima
# hampir sama dengan modul tulen — __name__/__package__/__spec__
# dikekalkan sebab ia sudah wujud betul dalam globals() ini,
# disediakan oleh Python sendiri sebelum baris ini jalan.
for _cs_name in ("base64", "_cs_dir", "_cs_p", "_cs_name"):
    globals().pop(_cs_name, None)

exec(_cs_compiled, globals())
