import os
import requests

API_ROOT = "https://api.telegram.org/bot{token}/{method}"
MAX_DOCUMENT_BYTES = 45 * 1024 * 1024  # Telegram's own bot API ceiling is ~50MB


def send_report(bot_token: str, chat_id: str, report_path: str, summary_text: str) -> dict:
    if not bot_token or not chat_id:
        return {"sent": False, "reason": "telegram not configured"}

    try:
        size = os.path.getsize(report_path)
        if size > MAX_DOCUMENT_BYTES:
            return {"sent": False, "reason": "report too large for Telegram, kept locally"}

        msg_resp = requests.post(
            API_ROOT.format(token=bot_token, method="sendMessage"),
            data={"chat_id": chat_id, "text": summary_text},
            timeout=15,
        )
        with open(report_path, "rb") as fh:
            doc_resp = requests.post(
                API_ROOT.format(token=bot_token, method="sendDocument"),
                data={"chat_id": chat_id},
                files={"document": fh},
                timeout=30,
            )

        if msg_resp.status_code == 200 and doc_resp.status_code == 200:
            return {"sent": True, "reason": ""}
        return {"sent": False, "reason": f"telegram API returned {msg_resp.status_code}/{doc_resp.status_code}"}
    except requests.Timeout:
        return {"sent": False, "reason": "timeout contacting Telegram"}
    except requests.RequestException as exc:
        return {"sent": False, "reason": f"network error: {exc}"}
