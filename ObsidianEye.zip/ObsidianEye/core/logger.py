class ScanLogger:
    """Collects module-level errors so one broken module never kills the run."""

    def __init__(self):
        self.errors = []

    def module_failed(self, module_name: str, exc: Exception):
        self.errors.append({
            "module": module_name,
            "error": f"{type(exc).__name__}: {exc}",
        })

    def to_list(self):
        return self.errors
