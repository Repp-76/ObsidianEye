import json
import os

CONFIG_DIR = os.path.dirname(__file__)
PROJECT_ROOT = os.path.dirname(CONFIG_DIR)
EXAMPLE_PATH = os.path.join(CONFIG_DIR, "config.json.example")

# Look in the usual spot first, then the project root — people often drop
# config.json next to main.py by mistake, so accept that too instead of
# silently failing.
CANDIDATE_PATHS = [
    os.path.join(CONFIG_DIR, "config.json"),
    os.path.join(PROJECT_ROOT, "config.json"),
]

DEFAULTS = {
    "telegram": {"bot_token": "", "chat_id": ""},
    "scan": {
        "timeout": 10,
        "delay": 0.15,
        "max_retries": 2,
        "crawl_depth": 2,
        "crawl_page_limit": 60,
        "verify_tls": True,
    },
}


def _find_config_path():
    for path in CANDIDATE_PATHS:
        if os.path.exists(path):
            return path
    return None


def load_config():
    """Returns (config_dict, info_dict). info_dict always has 'path' and
    'error' so the caller can tell the user exactly what happened instead
    of a plain 'not configured'."""
    path = _find_config_path()
    info = {"path": path, "error": None}

    if path is None:
        return DEFAULTS, info

    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except json.JSONDecodeError as exc:
        info["error"] = f"config.json is not valid JSON: {exc}"
        return DEFAULTS, info
    except OSError as exc:
        info["error"] = f"could not read config.json: {exc}"
        return DEFAULTS, info

    merged = {**DEFAULTS, **data}
    merged["scan"] = {**DEFAULTS["scan"], **data.get("scan", {})}
    merged["telegram"] = {**DEFAULTS["telegram"], **data.get("telegram", {})}
    return merged, info


def telegram_configured(cfg: dict) -> bool:
    tg = cfg.get("telegram", {})
    return bool(tg.get("bot_token")) and bool(tg.get("chat_id"))


def config_status_lines(cfg: dict, info: dict):
    lines = []
    if info["error"]:
        lines.append(("error", info["error"]))
    elif info["path"] is None:
        lines.append(("warn", f"config.json not found (looked in: {', '.join(CANDIDATE_PATHS)})"))
    else:
        lines.append(("ok", f"config.json loaded from {info['path']}"))

    if telegram_configured(cfg):
        chat_id = str(cfg["telegram"]["chat_id"])
        tail = chat_id[-4:] if len(chat_id) > 4 else chat_id
        lines.append(("ok", f"Telegram configured (chat ...{tail})"))
    else:
        tg = cfg.get("telegram", {})
        missing = [k for k in ("bot_token", "chat_id") if not tg.get(k)]
        lines.append(("warn", f"Telegram not configured — missing: {', '.join(missing) or 'unknown'}"))
    return lines
