import json
import os

CONFIG_DIR = os.path.dirname(__file__)
CONFIG_PATH = os.path.join(CONFIG_DIR, "config.json")
EXAMPLE_PATH = os.path.join(CONFIG_DIR, "config.json.example")

DEFAULTS = {
    "telegram": {"bot_token": "", "chat_id": ""},
    "scan": {
        "timeout": 10,
        "delay": 0.15,
        "max_retries": 2,
        "crawl_depth": 2,
        "crawl_page_limit": 60,
        "verify_tls": True,
    },
}


def load_config() -> dict:
    path = CONFIG_PATH if os.path.exists(CONFIG_PATH) else None
    if path is None:
        return DEFAULTS
    with open(path, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    merged = {**DEFAULTS, **data}
    merged["scan"] = {**DEFAULTS["scan"], **data.get("scan", {})}
    merged["telegram"] = {**DEFAULTS["telegram"], **data.get("telegram", {})}
    return merged


def telegram_configured(cfg: dict) -> bool:
    tg = cfg.get("telegram", {})
    return bool(tg.get("bot_token")) and bool(tg.get("chat_id"))
