# ObsidianEye

Advanced Web Security Intelligence Auditor
Developer: **Repp76**

ObsidianEye is a modular, non-destructive web security auditing framework.
It performs a broad, safe assessment of a target's HTTP/TLS configuration,
security headers, cookies, CORS, crawlable surface, authentication posture,
and a set of harmless indicator-based checks for common vulnerability
classes (XSS, SQLi, SSRF, traversal, open redirect, and more).

It is built for authorized security auditing: your own sites, internal
testing, or environments where you have explicit permission to test.

## What it does not do

ObsidianEye never brute forces credentials, floods a target, dumps a
database, exploits a vulnerability, or touches private/internal
infrastructure. For attack classes that are normally destructive
(brute force, DoS), ObsidianEye instead audits the *defensive control*
around them — e.g. "does this login endpoint show any rate-limiting
signal?" rather than actually trying to break in.

Every automated probe used for indicator-style checks (XSS reflection,
SQL error signatures, template injection, open redirect, traversal) uses
harmless markers and read-only requests. Nothing is uploaded, deleted,
or modified.

## Architecture

```
obsidianeye/
├── main.py                 entry point / terminal UI
├── config/
│   ├── config.json.example
│   └── loader.py
├── core/
│   ├── engine.py            runs modules against a target, profile-aware
│   ├── http_client.py       retry/backoff/429-aware request wrapper
│   ├── crawler.py           same-origin crawler (depth + page limited)
│   ├── fingerprint.py       technology signature matching
│   ├── findings.py          Finding model + collector
│   ├── correlation.py       combines related findings into observations
│   ├── reporter.py          builds/validates/saves the JSON report
│   ├── telegram.py          sends the report to a Telegram chat
│   └── logger.py            per-module error tracking
├── modules/                 one file per security category (32 modules)
├── utils/                   colors, validators, sanitizer, helpers
└── reports/                 JSON reports land here
```

Each module is a small class exposing `name`, `category`, `description`,
`safe`, and a `scan(ctx)` method. `ctx.shared` is a scratch dict that
earlier modules (recon, headers, crawl) populate and later modules
(injection, auth, API) read from — so the crawler only runs once and
every downstream module builds on the same data.

## Installation (Termux)

```
pkg update
pkg install python
pip install -r requirements.txt
python main.py
```

Works the same way on desktop Linux/macOS with a normal Python 3.9+
virtualenv.

## Telegram configuration

Copy `config/config.json.example` to `config/config.json` and fill in
your bot token and chat ID:

```json
{
  "telegram": {
    "bot_token": "123456:ABC-your-bot-token",
    "chat_id": "your-chat-id"
  }
}
```

If this file is missing or incomplete, ObsidianEye still runs and saves
the JSON report locally — it just skips the Telegram delivery step and
tells you so. The token is never printed to the terminal or embedded in
the report.

## Scan profiles

| Profile  | Coverage |
|----------|----------|
| QUICK    | Recon, DNS, HTTP, TLS, headers, cookies, CORS, fingerprinting |
| STANDARD | QUICK + crawling, forms, auth posture, sessions, CSRF, security.txt/robots, file exposure, cache |
| FULL     | STANDARD + injection indicators, SSRF/traversal indicators, brute-force & rate-limit audits, authorization indicators, GraphQL, WebSocket discovery, JS analysis, dependency exposure |
| CUSTOM   | Pick any subset of the 32 categories by number |

## JSON reports

Every scan writes `reports/<hostname>_<timestamp>.json` containing the
target info, every finding, correlated observations, module errors, and
run statistics. The JSON is validated (`json.loads` round-trip) before
it's written to disk.

## Finding severity vs. confidence

Findings carry both, and they're not the same thing:

- **Severity** — CRITICAL / HIGH / MEDIUM / LOW / INFO — how bad it is
  *if* it's real.
- **Confidence** — CONFIRMED / HIGH / MEDIUM / LOW / POTENTIAL — how sure
  ObsidianEye is that it's real.

A `POTENTIAL`-confidence finding is a lead worth checking manually, not
a confirmed vulnerability. ObsidianEye never claims a target is "fully
secure" — absence of findings means absence of what this scan could
safely detect, nothing more.

## Troubleshooting

- **Slow scans / lots of retries** — the target may be rate-limiting;
  the HTTP client automatically backs off on 429s and 5xx responses.
- **`ModuleNotFoundError: dns`** — DNS module falls back to basic
  `socket` resolution if `dnspython` isn't installed; install it for
  full record-type coverage (`pip install dnspython`).
- **No findings at all** — check `errors` in the JSON report; a target
  that blocks the scanner's user agent or requires JS rendering will
  limit what a request-based crawler can see.

## Limitations

- The crawler does not execute JavaScript, so client-side-rendered
  apps will be under-crawled.
- Indicator-based checks (XSS/SQLi/SSTI/etc.) are intentionally
  conservative to stay non-destructive — they flag leads, not proof.
- No CVE database is bundled; dependency/version exposure is reported
  as raw data for you to check against an advisory feed yourself.

## Authorized use only

Run ObsidianEye only against systems you own or have explicit written
permission to test. The tool's non-destructive design reduces risk but
does not make unauthorized scanning legal or acceptable.
