from modules.base import ScanModule
from core.crawler import Crawler

INTERESTING_PATH_HINTS = (
    "/api/", "/admin", "/login", "/register", "/logout", "/auth", "/oauth",
    "/graphql", "/upload", "/webhook", "/password", "/reset", "/debug",
    "/internal", "/config", "/.git", "/swagger", "/openapi",
)


class CrawlModule(ScanModule):
    name = "Crawler & Endpoint Discovery"
    category = "crawling"
    description = "Same-origin crawl that discovers pages, forms, scripts and likely-interesting endpoints."
    safe = True

    def __init__(self, depth=2, page_limit=60):
        self.depth = depth
        self.page_limit = page_limit

    def scan(self, ctx):
        crawler = Crawler(ctx.client, ctx.target["url"], depth=self.depth, page_limit=self.page_limit)
        data = crawler.run()

        interesting = sorted({
            p["url"] for p in data["pages"]
            if any(hint in p["url"].lower() for hint in INTERESTING_PATH_HINTS)
        })

        ctx.shared["crawl"] = data
        ctx.shared["endpoints"] = [p["url"] for p in data["pages"]]
        ctx.shared["interesting_endpoints"] = interesting
        ctx.shared["forms"] = data["forms"]
        ctx.shared["scripts"] = data["scripts"]

        forms_without_https = [
            f for f in data["forms"]
            if f["action"].startswith("http://") and ctx.target["scheme"] == "https"
        ]
        if forms_without_https:
            ctx.collector.add(
                title="Form Submits Over Plain HTTP",
                category="Forms",
                severity="HIGH",
                confidence="CONFIRMED",
                url=forms_without_https[0]["page"],
                method=forms_without_https[0]["method"],
                description=f"{len(forms_without_https)} form(s) submit to an HTTP action from an HTTPS page.",
                evidence=forms_without_https[0]["action"],
                impact="Submitted form data, potentially including credentials, would travel unencrypted.",
                recommendation="Point form actions at HTTPS endpoints only.",
                module=self.name,
            )

        state_changing_no_csrf = [
            f for f in data["forms"]
            if f["method"] == "POST" and not f["has_csrf_field"]
        ]
        if state_changing_no_csrf:
            ctx.collector.add(
                title="POST Form Without Visible CSRF Token",
                category="CSRF",
                severity="MEDIUM",
                confidence="LOW",
                url=state_changing_no_csrf[0]["page"],
                method="POST",
                description=(
                    f"{len(state_changing_no_csrf)} POST form(s) have no field that looks like a CSRF token. "
                    "Some frameworks protect via cookies/headers instead, so this is a lead, not a confirmed gap."
                ),
                evidence="No input named containing 'csrf' or 'token' found in the form.",
                impact="If the app truly lacks CSRF protection here, state-changing requests could be forged.",
                recommendation="Confirm CSRF protection exists (token, SameSite cookies, or custom header check).",
                module=self.name,
            )
