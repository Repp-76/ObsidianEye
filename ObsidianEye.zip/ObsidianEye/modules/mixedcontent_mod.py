from bs4 import BeautifulSoup
from modules.base import ScanModule


class MixedContentModule(ScanModule):
    name = "Mixed Content"
    category = "mixed_content"
    description = "On HTTPS pages, looks for scripts/styles/images/iframes loaded over plain HTTP."
    safe = True

    def scan(self, ctx):
        if ctx.target["scheme"] != "https":
            return
        resp = ctx.shared.get("baseline_response")
        if resp is None:
            return
        soup = BeautifulSoup(resp.text or "", "html.parser")

        insecure = []
        for tag, attr in (("script", "src"), ("link", "href"), ("img", "src"), ("iframe", "src")):
            for el in soup.find_all(tag):
                val = el.get(attr, "")
                if val.startswith("http://"):
                    insecure.append(val)

        if insecure:
            ctx.collector.add(
                title="Mixed Content Detected",
                category="Mixed Content",
                severity="MEDIUM",
                confidence="CONFIRMED",
                url=ctx.target["url"],
                description=f"{len(insecure)} resource(s) are loaded over HTTP on an HTTPS page.",
                evidence=f"Example: {insecure[0]}",
                impact="Browsers may block or warn on these resources, and they can be tampered with in transit.",
                recommendation="Serve all page resources over HTTPS; use protocol-relative or absolute HTTPS URLs.",
                module=self.name,
            )
