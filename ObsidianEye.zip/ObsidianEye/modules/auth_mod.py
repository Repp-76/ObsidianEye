from modules.base import ScanModule

LOGIN_HINTS = ("login", "signin", "sign-in", "auth")


class AuthModule(ScanModule):
    name = "Authentication Posture"
    category = "authentication"
    description = "Inspects login forms for HTTPS usage, autocomplete and username-enumeration indicators."
    safe = True

    def scan(self, ctx):
        forms = ctx.shared.get("forms", [])
        login_forms = [
            f for f in forms
            if any(h in f["page"].lower() or h in f["action"].lower() for h in LOGIN_HINTS)
            or any((i["type"] or "").lower() == "password" for i in f["inputs"])
        ]
        ctx.shared["login_forms"] = login_forms
        if not login_forms:
            return

        form = login_forms[0]
        if not form["action"].startswith("https://") and ctx.target["scheme"] == "https":
            ctx.collector.add(
                title="Login Form Submits Over Plain HTTP",
                category="Authentication",
                severity="CRITICAL",
                confidence="CONFIRMED",
                url=form["page"],
                method=form["method"],
                description="A form containing a password field submits to a non-HTTPS action.",
                evidence=f"action={form['action']}",
                impact="Credentials would be transmitted in cleartext and could be intercepted.",
                recommendation="Submit authentication forms only to HTTPS endpoints.",
                module=self.name,
            )

        pw_fields = [i for i in form["inputs"] if (i["type"] or "").lower() == "password"]
        if pw_fields and pw_fields[0].get("autocomplete", "").lower() not in ("off", "new-password"):
            ctx.collector.add(
                title="Password Field Allows Autocomplete",
                category="Authentication",
                severity="INFO",
                confidence="CONFIRMED",
                url=form["page"],
                description="The password field does not set autocomplete=off/new-password.",
                evidence=f"autocomplete={pw_fields[0].get('autocomplete') or '(unset)'}",
                impact="Minor: browsers may offer to store/fill the password on shared devices.",
                recommendation="Set autocomplete appropriately based on your threat model (this is a minor, often-accepted trade-off).",
                module=self.name,
            )

        try:
            username_field = next((i["name"] for i in form["inputs"] if "user" in (i["name"] or "").lower() or "email" in (i["name"] or "").lower()), None)
            pw_field = pw_fields[0]["name"] if pw_fields else None
            if username_field and pw_field:
                r1 = ctx.client.post(form["action"], data={username_field: "obsidianeye_no_such_user_9f3", pw_field: "wrongpass"})
                r2 = ctx.client.post(form["action"], data={username_field: "admin", pw_field: "wrongpass"})
                if r1 is not None and r2 is not None:
                    if r1.status_code != r2.status_code or len(r1.text or "") != len(r2.text or ""):
                        ctx.collector.add(
                            title="Inconsistent Authentication Errors",
                            category="Authentication",
                            severity="MEDIUM",
                            confidence="MEDIUM",
                            url=form["action"],
                            method="POST",
                            description="Login responses differ between a clearly-invalid username and a common one, both with a wrong password.",
                            evidence=f"status {r1.status_code}/{r2.status_code}, length {len(r1.text or '')}/{len(r2.text or '')}",
                            impact="Attackers can enumerate valid usernames before attempting credential attacks.",
                            recommendation="Return identical responses regardless of whether the username exists.",
                            module=self.name,
                        )
        except Exception:
            pass
