import re
from modules.base import ScanModule

VERSION_RE = re.compile(r"([A-Za-z][\w.\-]*)[/ ]v?(\d+\.\d+(\.\d+)?)")


class DependencyExposureModule(ScanModule):
    name = "Dependency & Version Exposure"
    category = "dependencies"
    description = "Collects version strings leaked via headers/HTML so they can be checked against advisories later."
    safe = True

    def scan(self, ctx):
        headers = ctx.shared.get("headers", {})
        exposed = []
        for header in ("Server", "X-Powered-By"):
            value = headers.get(header, "")
            match = VERSION_RE.search(value)
            if match:
                exposed.append({"source": header, "component": match.group(1), "version": match.group(2)})

        for script_url in ctx.shared.get("scripts", []):
            match = VERSION_RE.search(script_url)
            if match and match.group(1).lower() not in ("http", "https"):
                exposed.append({"source": "script filename", "component": match.group(1), "version": match.group(2)})

        ctx.shared["dependencies"] = exposed
        if exposed:
            first = exposed[0]
            ctx.collector.add(
                title="Software Version Exposed",
                category="Dependency Exposure",
                severity="INFO",
                confidence="HIGH",
                url=ctx.target["url"],
                description=f"{len(exposed)} version string(s) were observed (e.g. {first['component']} {first['version']}).",
                evidence=f"source={first['source']}",
                impact="Exposed versions make it easier for an attacker to look up known CVEs for that exact release.",
                recommendation="Suppress version banners (Server/X-Powered-By) and keep dependencies patched regardless.",
                module=self.name,
            )
