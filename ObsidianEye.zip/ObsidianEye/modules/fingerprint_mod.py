from modules.base import ScanModule
from core.fingerprint import fingerprint


class FingerprintModule(ScanModule):
    name = "Technology Fingerprinting"
    category = "fingerprinting"
    description = "Combines headers, HTML and cookie names to identify CMS/framework/server/CDN technologies."
    safe = True

    def scan(self, ctx):
        headers = ctx.shared.get("headers", {})
        resp = ctx.shared.get("baseline_response")
        html = resp.text if resp is not None else ""
        cookie_names = [c["name"] for c in ctx.shared.get("cookies", [])]

        hits = fingerprint(headers, html, cookie_names)
        ctx.shared["technologies"] = hits

        if hits:
            summary = ", ".join(sorted({h["technology"] for h in hits}))
            ctx.collector.add(
                title="Technology Stack Identified",
                category="Fingerprinting",
                severity="INFO",
                confidence="MEDIUM",
                url=ctx.target["url"],
                description=f"Fingerprinting identified: {summary}.",
                evidence="Matched via response headers, HTML markers and/or cookie names.",
                impact="Knowing the stack lets an attacker target known weaknesses for that specific technology.",
                recommendation="Not a vulnerability by itself; suppress unnecessary version banners where practical.",
                module=self.name,
            )
