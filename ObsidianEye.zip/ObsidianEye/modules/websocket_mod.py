import re
from modules.base import ScanModule

WS_RE = re.compile(r"""wss?://[^\s"'<>]+""")


class WebSocketModule(ScanModule):
    name = "WebSocket Discovery"
    category = "websocket"
    description = "Scans crawled HTML/JS for ws:// or wss:// endpoint references."
    safe = True

    def scan(self, ctx):
        found = set()
        for script_url in ctx.shared.get("scripts", []):
            try:
                resp = ctx.client.get(script_url)
            except Exception:
                continue
            if resp is None:
                continue
            found.update(WS_RE.findall(resp.text or ""))

        if not found:
            return
        ctx.shared["websockets"] = sorted(found)

        insecure = [w for w in found if w.startswith("ws://")]
        if insecure:
            ctx.collector.add(
                title="Insecure WebSocket Endpoint (ws://)",
                category="WebSocket",
                severity="MEDIUM",
                confidence="CONFIRMED",
                url=insecure[0],
                description=f"{len(insecure)} unencrypted WebSocket endpoint(s) were referenced in client code.",
                evidence=f"Example: {insecure[0]}",
                impact="WebSocket traffic can be intercepted or tampered with on the network path.",
                recommendation="Use wss:// exclusively for WebSocket connections.",
                module=self.name,
            )
