import ssl
import socket
from datetime import datetime

from modules.base import ScanModule


class TlsModule(ScanModule):
    name = "TLS/SSL Analysis"
    category = "tls"
    description = "Inspects the certificate chain, validity window and negotiated protocol."
    safe = True

    def scan(self, ctx):
        target = ctx.target
        if target["scheme"] != "https":
            ctx.shared["tls"] = {"enabled": False}
            return

        hostname = target["hostname"]
        port = target["port"]
        info = {"enabled": True}

        context = ssl.create_default_context()
        try:
            with socket.create_connection((hostname, port), timeout=8) as sock:
                with context.wrap_socket(sock, server_hostname=hostname) as ssock:
                    cert = ssock.getpeercert()
                    info["protocol"] = ssock.version()
                    info["cipher"] = ssock.cipher()[0] if ssock.cipher() else None
                    info["issuer"] = dict(x[0] for x in cert.get("issuer", []))
                    info["subject"] = dict(x[0] for x in cert.get("subject", []))
                    info["not_before"] = cert.get("notBefore")
                    info["not_after"] = cert.get("notAfter")
                    info["san"] = [v for k, v in cert.get("subjectAltName", []) if k == "DNS"]

                    if info["not_after"]:
                        expires = datetime.strptime(info["not_after"], "%b %d %H:%M:%S %Y %Z")
                        days_left = (expires - datetime.utcnow()).days
                        info["days_until_expiry"] = days_left
                        if days_left < 0:
                            ctx.collector.add(
                                title="Expired TLS Certificate",
                                category="TLS",
                                severity="CRITICAL",
                                confidence="CONFIRMED",
                                url=target["url"],
                                description="The presented TLS certificate has already expired.",
                                evidence=f"notAfter={info['not_after']}",
                                impact="Browsers will show hard security warnings; MITM protection is effectively broken for users who click through.",
                                recommendation="Renew the TLS certificate immediately.",
                                module=self.name,
                            )
                        elif days_left < 15:
                            ctx.collector.add(
                                title="TLS Certificate Expiring Soon",
                                category="TLS",
                                severity="MEDIUM",
                                confidence="CONFIRMED",
                                url=target["url"],
                                description=f"The TLS certificate expires in {days_left} day(s).",
                                evidence=f"notAfter={info['not_after']}",
                                impact="An expired certificate will break HTTPS access and trigger browser warnings.",
                                recommendation="Renew the certificate before expiry, ideally via automated renewal.",
                                module=self.name,
                            )

                    if info.get("protocol") in ("TLSv1", "TLSv1.1"):
                        ctx.collector.add(
                            title="Outdated TLS Protocol Negotiated",
                            category="TLS",
                            severity="HIGH",
                            confidence="CONFIRMED",
                            url=target["url"],
                            description=f"The server negotiated {info['protocol']}, which is deprecated.",
                            evidence=f"Negotiated protocol: {info['protocol']}",
                            impact="Deprecated TLS versions carry known cryptographic weaknesses.",
                            recommendation="Disable TLS 1.0/1.1 and require TLS 1.2 or newer.",
                            module=self.name,
                        )

                    hostname_ok = True
                    try:
                        ssl.match_hostname(cert, hostname) if hasattr(ssl, "match_hostname") else None
                    except Exception:
                        hostname_ok = False
                    info["hostname_matches"] = hostname_ok

        except (socket.timeout, socket.gaierror, ConnectionRefusedError, ssl.SSLError) as exc:
            info["error"] = str(exc)
            ctx.collector.add(
                title="TLS Handshake Failed",
                category="TLS",
                severity="HIGH",
                confidence="HIGH",
                url=target["url"],
                description="Could not complete a TLS handshake with the target.",
                evidence=str(exc),
                impact="HTTPS may be misconfigured or unavailable, which can force users onto plain HTTP.",
                recommendation="Verify the certificate chain and TLS configuration on the server.",
                module=self.name,
            )

        ctx.shared["tls"] = info
