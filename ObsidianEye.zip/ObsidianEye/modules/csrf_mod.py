from modules.base import ScanModule


class CsrfModule(ScanModule):
    name = "CSRF Protection Audit"
    category = "csrf"
    description = "Checks cookie SameSite settings and per-form CSRF token presence."
    safe = True

    def scan(self, ctx):
        cookies = ctx.shared.get("cookies", [])
        session_cookies = [c for c in cookies if c["sensitive_name"]]
        weak_samesite = [c for c in session_cookies if (c["same_site"] or "").lower() not in ("lax", "strict")]

        if session_cookies and weak_samesite:
            ctx.collector.add(
                title="Session Cookie Without Strong SameSite",
                category="CSRF",
                severity="MEDIUM",
                confidence="MEDIUM",
                url=ctx.target["url"],
                description="Session-like cookies do not set SameSite=Lax/Strict, so browser-level CSRF mitigation is not in effect.",
                evidence=f"Affected cookies: {[c['name'] for c in weak_samesite]}",
                impact="Relies entirely on token-based CSRF protection, if any exists.",
                recommendation="Set SameSite=Lax (or Strict where compatible) on session cookies.",
                module=self.name,
            )
