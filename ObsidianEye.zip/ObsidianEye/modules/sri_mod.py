from bs4 import BeautifulSoup
from urllib.parse import urlparse
from modules.base import ScanModule


class SriModule(ScanModule):
    name = "Subresource Integrity"
    category = "sri"
    description = "Checks cross-origin scripts/stylesheets for a missing integrity attribute."
    safe = True

    def scan(self, ctx):
        resp = ctx.shared.get("baseline_response")
        if resp is None:
            return
        soup = BeautifulSoup(resp.text or "", "html.parser")
        target_host = urlparse(ctx.target["url"]).hostname

        missing = []
        for tag, attr in (("script", "src"), ("link", "href")):
            for el in soup.find_all(tag):
                src = el.get(attr, "")
                if not src.startswith("http"):
                    continue
                if urlparse(src).hostname != target_host and not el.get("integrity"):
                    missing.append(src)

        if missing:
            ctx.collector.add(
                title="Cross-Origin Resource Without Subresource Integrity",
                category="SRI",
                severity="LOW",
                confidence="CONFIRMED",
                url=ctx.target["url"],
                description=f"{len(missing)} cross-origin script/stylesheet(s) load without an integrity attribute.",
                evidence=f"Example: {missing[0]}",
                impact="If the third-party host is compromised, its content would be trusted and executed/applied unchanged.",
                recommendation="Add integrity + crossorigin attributes to cross-origin scripts and stylesheets.",
                module=self.name,
            )
