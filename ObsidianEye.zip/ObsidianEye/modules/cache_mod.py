from modules.base import ScanModule


class CacheModule(ScanModule):
    name = "Cache Security"
    category = "caching"
    description = "Checks Cache-Control/Vary handling, especially on pages that look authenticated."
    safe = True

    def scan(self, ctx):
        headers = ctx.shared.get("headers", {})
        cache_control = headers.get("Cache-Control", "")
        has_session_cookie = any(c["sensitive_name"] for c in ctx.shared.get("cookies", []))

        if has_session_cookie and "private" not in cache_control.lower() and "no-store" not in cache_control.lower():
            ctx.collector.add(
                title="Authenticated Response Cacheable by Shared Caches",
                category="Cache",
                severity="MEDIUM",
                confidence="MEDIUM",
                url=ctx.target["url"],
                description="A response that also sets a session cookie doesn't mark itself private/no-store.",
                evidence=f"Cache-Control: {cache_control or '(absent)'}",
                impact="A shared cache/proxy could serve one user's authenticated response to another user.",
                recommendation="Mark authenticated responses 'Cache-Control: private, no-store' as appropriate.",
                module=self.name,
            )

        if "Vary" not in headers and headers.get("Content-Encoding"):
            ctx.collector.add(
                title="Missing Vary Header With Content Negotiation",
                category="Cache",
                severity="INFO",
                confidence="LOW",
                url=ctx.target["url"],
                description="Content-Encoding is used but no Vary header is present.",
                evidence=f"Content-Encoding: {headers.get('Content-Encoding')}",
                impact="Intermediate caches may serve a compressed response to a client that can't decode it, or vice versa.",
                recommendation="Add 'Vary: Accept-Encoding' (and other negotiated headers) as appropriate.",
                module=self.name,
            )
