import re
from modules.base import ScanModule

PATTERNS = {
    "Stack trace": re.compile(r"(Traceback \(most recent call last\)|at [\w.$]+\(.*:\d+:\d+\)|#0 \S+\(\d+\))"),
    "Filesystem path": re.compile(r"([A-Za-z]:\\[\w\\.]+|/(var|home|usr|opt)/[\w/.\-]+)"),
    "Internal IP": re.compile(r"\b(10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.(1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3})\b"),
    "SQL error": re.compile(r"(SQLSTATE\[|SQL syntax.*MySQL|pg_query\(\))", re.IGNORECASE),
    "Framework debug page": re.compile(r"(Whitelabel Error Page|Django Debug|PHP Fatal error|Laravel\\\\Exceptions)"),
}


class ErrorDisclosureModule(ScanModule):
    name = "Error & Information Disclosure"
    category = "disclosure"
    description = "Requests a nonexistent page and inspects the error body for stack traces, paths or internal IPs."
    safe = True

    def scan(self, ctx):
        base = ctx.target["url"]
        probe_url = base + "/obsidianeye-nonexistent-9f3x2"
        try:
            resp = ctx.client.get(probe_url)
        except Exception:
            return
        if resp is None:
            return
        body = resp.text or ""

        for label, pattern in PATTERNS.items():
            match = pattern.search(body)
            if match:
                ctx.collector.add(
                    title=f"Information Disclosure: {label}",
                    category="Information Disclosure",
                    severity="MEDIUM" if label != "Internal IP" else "LOW",
                    confidence="MEDIUM",
                    url=probe_url,
                    description=f"A {label.lower()} was found in a 404/error response body.",
                    evidence=match.group(0)[:120],
                    impact="Verbose errors can hand an attacker internal paths, stack details or framework internals.",
                    recommendation="Return generic error pages in production; log details server-side only.",
                    module=self.name,
                )
