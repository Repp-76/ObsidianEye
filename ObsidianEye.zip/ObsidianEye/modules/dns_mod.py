from modules.base import ScanModule

try:
    import dns.resolver
    HAVE_DNSPYTHON = True
except ImportError:
    HAVE_DNSPYTHON = False

RECORD_TYPES = ("A", "AAAA", "CNAME", "MX", "NS", "TXT", "SOA", "CAA")


class DnsModule(ScanModule):
    name = "DNS Enumeration"
    category = "reconnaissance"
    description = "Resolves standard DNS record types for the target hostname."
    safe = True

    def scan(self, ctx):
        hostname = ctx.target["hostname"]
        records = {}

        if HAVE_DNSPYTHON:
            resolver = dns.resolver.Resolver()
            resolver.lifetime = 5
            for rtype in RECORD_TYPES:
                try:
                    answer = resolver.resolve(hostname, rtype)
                    records[rtype] = sorted(str(r).strip('"') for r in answer)
                except Exception:
                    records[rtype] = []
        else:
            import socket
            try:
                records["A"] = sorted({r[4][0] for r in socket.getaddrinfo(hostname, None, socket.AF_INET)})
            except Exception:
                records["A"] = []
            for rtype in RECORD_TYPES:
                records.setdefault(rtype, [])

        records["dnssec_signed"] = bool(records.get("TXT")) and any(
            "v=spf1" in t or "DMARC" in t for t in records.get("TXT", [])
        )
        ctx.shared["dns"] = records

        if not records.get("CAA"):
            ctx.collector.add(
                title="No CAA Record",
                category="DNS",
                severity="LOW",
                confidence="MEDIUM",
                url=ctx.target["url"],
                description="No Certificate Authority Authorization (CAA) record was found for the domain.",
                evidence="DNS query for CAA returned no records.",
                impact="Without CAA, any publicly trusted CA can issue certificates for this domain.",
                recommendation="Add a CAA record restricting issuance to your chosen certificate authority.",
                module=self.name,
            )
