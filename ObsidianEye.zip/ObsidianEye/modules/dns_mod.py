import socket

from modules.base import ScanModule

RECORD_TYPES = ("A", "AAAA", "CNAME", "MX", "NS", "TXT", "SOA", "CAA")


def _resolve_with_dnspython(hostname):
    """Returns a records dict, or None if dnspython isn't usable at all
    (not installed, or — common on Termux/Android — it can't read a
    system resolver config). Caller falls back to socket in that case."""
    try:
        import dns.resolver
    except ImportError:
        return None

    try:
        resolver = dns.resolver.Resolver()
        resolver.lifetime = 5
    except Exception:
        # Android/Termux often has no /etc/resolv.conf in the place
        # dnspython expects, which throws here before any query is made.
        return None

    records = {}
    for rtype in RECORD_TYPES:
        try:
            answer = resolver.resolve(hostname, rtype)
            records[rtype] = sorted(str(r).strip('"') for r in answer)
        except Exception:
            records[rtype] = []
    return records


def _resolve_with_socket(hostname):
    records = {rtype: [] for rtype in RECORD_TYPES}
    try:
        records["A"] = sorted({
            r[4][0] for r in socket.getaddrinfo(hostname, None, socket.AF_INET)
        })
    except Exception:
        pass
    try:
        records["AAAA"] = sorted({
            r[4][0] for r in socket.getaddrinfo(hostname, None, socket.AF_INET6)
        })
    except Exception:
        pass
    return records


class DnsModule(ScanModule):
    name = "DNS Enumeration"
    category = "reconnaissance"
    description = "Resolves standard DNS record types for the target hostname."
    safe = True

    def scan(self, ctx):
        hostname = ctx.target["hostname"]

        records = None
        try:
            records = _resolve_with_dnspython(hostname)
        except Exception:
            records = None
        if records is None:
            records = _resolve_with_socket(hostname)

        records["dnssec_signed"] = bool(records.get("TXT")) and any(
            "v=spf1" in t or "DMARC" in t for t in records.get("TXT", [])
        )
        ctx.shared["dns"] = records

        if not records.get("CAA"):
            ctx.collector.add(
                title="No CAA Record",
                category="DNS",
                severity="LOW",
                confidence="MEDIUM",
                url=ctx.target["url"],
                description="No Certificate Authority Authorization (CAA) record was found for the domain.",
                evidence="DNS query for CAA returned no records.",
                impact="Without CAA, any publicly trusted CA can issue certificates for this domain.",
                recommendation="Add a CAA record restricting issuance to your chosen certificate authority.",
                module=self.name,
            )
