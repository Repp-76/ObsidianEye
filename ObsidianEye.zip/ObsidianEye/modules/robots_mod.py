from modules.base import ScanModule


class RobotsSitemapModule(ScanModule):
    name = "robots.txt / sitemap.xml"
    category = "configuration"
    description = "Fetches robots.txt and sitemap.xml and extracts listed paths for context (never attacks them)."
    safe = True

    def scan(self, ctx):
        base = ctx.target["url"]
        disallowed = []
        try:
            resp = ctx.client.get(base + "/robots.txt")
            if resp is not None and resp.status_code == 200:
                for line in resp.text.splitlines():
                    line = line.strip()
                    if line.lower().startswith("disallow:"):
                        path = line.split(":", 1)[1].strip()
                        if path:
                            disallowed.append(path)
        except Exception:
            pass

        sitemap_urls = []
        try:
            resp = ctx.client.get(base + "/sitemap.xml")
            if resp is not None and resp.status_code == 200:
                import re
                sitemap_urls = re.findall(r"<loc>(.*?)</loc>", resp.text or "")
        except Exception:
            pass

        ctx.shared["robots_disallowed"] = disallowed
        ctx.shared["sitemap_urls"] = sitemap_urls

        sensitive_hints = ("/admin", "/backup", "/internal", "/private", "/config")
        leaked = [p for p in disallowed if any(h in p.lower() for h in sensitive_hints)]
        if leaked:
            ctx.collector.add(
                title="Sensitive-Looking Path Disclosed via robots.txt",
                category="Configuration",
                severity="LOW",
                confidence="MEDIUM",
                url=base + "/robots.txt",
                description=f"robots.txt lists {len(leaked)} path(s) that look administrative/internal.",
                evidence=f"Example disallowed path: {leaked[0]}",
                impact="robots.txt is publicly readable, so 'hiding' sensitive paths there just advertises them to attackers.",
                recommendation="Don't rely on robots.txt to hide sensitive paths; enforce real authentication instead.",
                module=self.name,
            )
