from modules.base import ScanModule


class SessionModule(ScanModule):
    name = "Session Security"
    category = "sessions"
    description = "Checks session cookie attributes and cache headers on cookie-bearing responses."
    safe = True

    def scan(self, ctx):
        cookies = ctx.shared.get("cookies", [])
        session_cookies = [c for c in cookies if c["sensitive_name"]]
        if not session_cookies:
            return

        headers = ctx.shared.get("headers", {})
        cache_control = headers.get("Cache-Control", "")
        if "no-store" not in cache_control.lower():
            ctx.collector.add(
                title="Session-Bearing Response Without no-store Caching",
                category="Sessions",
                severity="LOW",
                confidence="MEDIUM",
                url=ctx.target["url"],
                description="A response that sets a session cookie does not send Cache-Control: no-store.",
                evidence=f"Cache-Control: {cache_control or '(absent)'}",
                impact="Authenticated content could be cached by shared proxies or the browser disk cache.",
                recommendation="Send 'Cache-Control: no-store' on authenticated/session-bearing responses.",
                module=self.name,
            )

        no_expiry = [c for c in session_cookies if not c["expires"]]
        persistent = [c for c in session_cookies if c["expires"]]
        if persistent:
            ctx.collector.add(
                title="Session Cookie Set as Persistent",
                category="Sessions",
                severity="LOW",
                confidence="MEDIUM",
                url=ctx.target["url"],
                description="A session-like cookie has a fixed expiration instead of being a session cookie.",
                evidence=f"Cookies with expiry: {[c['name'] for c in persistent]}",
                impact="The session outlives the browser session, extending the window an attacker can reuse a stolen cookie.",
                recommendation="Consider session-only cookies for sensitive state, with server-side expiry/rotation.",
                module=self.name,
            )
