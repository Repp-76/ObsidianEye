import re
from modules.base import ScanModule

ADMIN_HINTS = ("/admin", "/administrator", "/manage", "/dashboard", "/internal", "/staff")
IDOR_ID_RE = re.compile(r"[?&](id|user_id|uid|account|order|invoice)=(\d+)", re.IGNORECASE)


class AuthorizationModule(ScanModule):
    name = "Authorization Indicators"
    category = "authorization"
    description = "Flags publicly reachable admin-looking paths and numeric-ID parameters worth reviewing for IDOR."
    safe = True

    def scan(self, ctx):
        pages = ctx.shared.get("crawl", {}).get("pages", [])
        exposed_admin = [p for p in pages if any(h in p["url"].lower() for h in ADMIN_HINTS) and p["status"] == 200]
        if exposed_admin:
            ctx.collector.add(
                title="Publicly Reachable Admin-Looking Path",
                category="Authorization",
                severity="MEDIUM",
                confidence="LOW",
                url=exposed_admin[0]["url"],
                description=f"{len(exposed_admin)} path(s) matching admin/management naming returned HTTP 200 without authentication prompts observed.",
                evidence=exposed_admin[0]["url"],
                impact="If this is genuinely an unauthenticated admin surface, it could allow unauthorized administrative access.",
                recommendation="Confirm authentication is enforced server-side for administrative routes, not just hidden from navigation.",
                module=self.name,
            )

        idor_candidates = [p["url"] for p in pages if IDOR_ID_RE.search(p["url"])]
        if idor_candidates:
            ctx.collector.add(
                title="Sequential Object Identifier in URL",
                category="Authorization",
                severity="LOW",
                confidence="POTENTIAL",
                url=idor_candidates[0],
                description=f"{len(idor_candidates)} URL(s) reference objects by a small sequential/numeric ID.",
                evidence=idor_candidates[0],
                impact="If access control isn't checked per-object, incrementing the ID could expose other users' data (IDOR).",
                recommendation="Verify server-side authorization checks the requesting user owns/can access the referenced object.",
                module=self.name,
            )
