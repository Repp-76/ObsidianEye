import re
from urllib.parse import urlparse, parse_qs, urlencode

from modules.base import ScanModule

XSS_MARKER = "oe9f3xss"
SQL_ERROR_PATTERNS = [
    re.compile(p, re.IGNORECASE) for p in (
        r"sql syntax.*mysql", r"warning.*mysqli", r"unclosed quotation mark",
        r"quoted string not properly terminated", r"pg_query\(\)",
        r"sqlite3.OperationalError", r"ORA-\d{5}", r"Microsoft OLE DB Provider for SQL Server",
        r"SQLSTATE\[",
    )
]
CMD_ERROR_PATTERNS = [
    re.compile(p, re.IGNORECASE) for p in (
        r"sh: .*not found", r"is not recognized as an internal or external command",
        r"/bin/sh:", r"cmd.exe",
    )
]
TEMPLATE_ECHO = "49*7"          # SSTI-style expression, harmless arithmetic
TEMPLATE_RESULT = "343"


def _urls_with_params(ctx):
    seen = {}
    for url in ctx.shared.get("endpoints", []):
        qs = parse_qs(urlparse(url).query)
        if qs:
            seen[url] = qs
    for form in ctx.shared.get("forms", []):
        if form["method"] == "GET" and form["inputs"]:
            qs = {i["name"]: ["1"] for i in form["inputs"] if i["name"]}
            if qs:
                seen[form["action"]] = qs
    return seen


class InjectionModule(ScanModule):
    name = "Injection Indicators (XSS / SQLi / Other)"
    category = "injection"
    description = "Safe, non-destructive probes for reflected XSS, SQL error signatures and template injection."
    safe = True

    def scan(self, ctx):
        url = ctx.target["url"]
        candidates = _urls_with_params(ctx)
        if not candidates:
            return

        checked = 0
        for target_url, params in candidates.items():
            if checked >= 15:  # cap probe volume, this is a passive-style audit not a fuzzer
                break
            base = urlparse(target_url)
            for param in list(params)[:3]:
                checked += 1
                self._probe_param(ctx, base, param)

    def _probe_param(self, ctx, base, param):
        test_url = base._replace(query=urlencode({param: XSS_MARKER})).geturl()
        try:
            resp = ctx.client.get(test_url)
        except Exception:
            return
        body = resp.text or ""

        if XSS_MARKER in body:
            context = self._reflection_context(body, XSS_MARKER)
            ctx.collector.add(
                title="Reflected Parameter",
                category="XSS",
                severity="MEDIUM" if context == "html" else "LOW",
                confidence="MEDIUM" if context == "html" else "LOW",
                url=test_url,
                method="GET",
                parameter=param,
                description=f"Parameter '{param}' is reflected unencoded in a {context} context.",
                evidence=f"Marker '{XSS_MARKER}' found verbatim in response body.",
                impact="If untrusted input reaches the page without encoding, reflected XSS may be possible.",
                recommendation="Context-encode all reflected output; consider a strict CSP as defense-in-depth.",
                module=self.name,
            )

        sql_url = base._replace(query=urlencode({param: "o'e"})).geturl()
        try:
            sql_resp = ctx.client.get(sql_url)
        except Exception:
            sql_resp = None
        if sql_resp is not None:
            for pattern in SQL_ERROR_PATTERNS:
                if pattern.search(sql_resp.text or ""):
                    ctx.collector.add(
                        title="Possible SQL Injection Indicator",
                        category="SQL Injection",
                        severity="HIGH",
                        confidence="POTENTIAL",
                        url=sql_url,
                        method="GET",
                        parameter=param,
                        description=f"A single quote in parameter '{param}' triggered a database error signature.",
                        evidence=f"Response matched pattern: {pattern.pattern}",
                        impact="Unsanitized input reaching a SQL query can allow data exposure or tampering.",
                        recommendation="Use parameterized queries/prepared statements; never build SQL via string concatenation.",
                        module=self.name,
                    )
                    break

            for pattern in CMD_ERROR_PATTERNS:
                if pattern.search(sql_resp.text or ""):
                    ctx.collector.add(
                        title="Possible Command Injection Indicator",
                        category="Command Injection",
                        severity="HIGH",
                        confidence="POTENTIAL",
                        url=sql_url,
                        method="GET",
                        parameter=param,
                        description=f"Parameter '{param}' triggered what looks like a shell error message.",
                        evidence=f"Response matched pattern: {pattern.pattern}",
                        impact="Input may be passed to a system shell, which can lead to arbitrary command execution.",
                        recommendation="Avoid shelling out with user input; use safe APIs and strict allowlisting.",
                        module=self.name,
                    )
                    break

        tmpl_url = base._replace(query=urlencode({param: "${7*7}"})).geturl()
        try:
            tmpl_resp = ctx.client.get(tmpl_url)
            if tmpl_resp is not None and "49" in (tmpl_resp.text or "") and "${7*7}" not in tmpl_resp.text:
                ctx.collector.add(
                    title="Possible Server-Side Template Injection Indicator",
                    category="Template Injection",
                    severity="HIGH",
                    confidence="POTENTIAL",
                    url=tmpl_url,
                    method="GET",
                    parameter=param,
                    description=f"An arithmetic template expression in '{param}' appears to have been evaluated.",
                    evidence="Response contains '49' where the literal expression '${7*7}' was sent.",
                    impact="Template injection can often escalate to remote code execution.",
                    recommendation="Never render user input as a template string; treat it strictly as data.",
                    module=self.name,
                )
        except Exception:
            pass

    @staticmethod
    def _reflection_context(body, marker):
        idx = body.find(marker)
        if idx == -1:
            return "unknown"
        window = body[max(0, idx - 40):idx]
        if re.search(r'=["\']?[^"\'>]*$', window):
            return "attribute"
        if "<script" in body[max(0, idx - 200):idx].lower():
            return "javascript"
        return "html"
