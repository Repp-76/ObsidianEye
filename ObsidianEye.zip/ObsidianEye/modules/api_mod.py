from modules.base import ScanModule

DOC_PATHS = ("/swagger.json", "/swagger-ui", "/openapi.json", "/api-docs", "/v1/swagger.json")


class ApiModule(ScanModule):
    name = "API Security"
    category = "api"
    description = "Looks for exposed API documentation, versioned endpoints and verbose JSON errors."
    safe = True

    def scan(self, ctx):
        base = ctx.target["url"]
        apis = [e for e in ctx.shared.get("endpoints", []) if "/api/" in e.lower()]
        ctx.shared["apis"] = apis

        for path in DOC_PATHS:
            try:
                resp = ctx.client.get(base + path)
            except Exception:
                continue
            if resp is not None and resp.status_code == 200 and (
                "swagger" in (resp.text or "").lower() or "openapi" in (resp.text or "").lower()
            ):
                ctx.collector.add(
                    title="Exposed API Documentation",
                    category="API",
                    severity="INFO",
                    confidence="HIGH",
                    url=base + path,
                    description=f"API documentation is publicly reachable at {path}.",
                    evidence=f"HTTP 200 with Swagger/OpenAPI content at {path}",
                    impact="Documentation can reveal the full attack surface, including undocumented-elsewhere endpoints.",
                    recommendation="Restrict API documentation to authenticated/internal users if it's not meant to be public.",
                    module=self.name,
                )
                break

        if apis:
            try:
                probe = ctx.client.get(apis[0] + ("&" if "?" in apis[0] else "?") + "obsidianeye_bad_param=1")
                if probe is not None and probe.headers.get("Content-Type", "").startswith("application/json"):
                    body = probe.text or ""
                    if "traceback" in body.lower() or "stack" in body.lower() or "exception" in body.lower():
                        ctx.collector.add(
                            title="Verbose API Error Response",
                            category="API",
                            severity="LOW",
                            confidence="MEDIUM",
                            url=apis[0],
                            description="An API endpoint returned a stack trace or exception detail in a JSON error.",
                            evidence="Response body contains trace/exception-like content.",
                            impact="Verbose errors can leak internal paths, library versions or logic details.",
                            recommendation="Return generic error messages to clients; log details server-side only.",
                            module=self.name,
                        )
            except Exception:
                pass
