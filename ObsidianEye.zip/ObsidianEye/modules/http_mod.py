from modules.base import ScanModule

RISKY_METHODS = ("PUT", "DELETE", "TRACE", "CONNECT")


class HttpModule(ScanModule):
    name = "HTTP Security"
    category = "http"
    description = "Checks HTTPS enforcement, redirect behavior and allowed HTTP methods."
    safe = True

    def scan(self, ctx):
        target = ctx.target
        url = target["url"]
        result = {}

        if target["scheme"] == "https":
            http_url = "http://" + target["hostname"]
            try:
                resp = ctx.client.get(http_url, allow_redirects=True)
                result["http_redirects_to_https"] = resp.url.startswith("https://")
            except Exception:
                result["http_redirects_to_https"] = None
        else:
            result["http_redirects_to_https"] = False
            ctx.collector.add(
                title="Site Served Over Plain HTTP",
                category="HTTP",
                severity="HIGH",
                confidence="CONFIRMED",
                url=url,
                description="The target was reached over HTTP without being redirected to HTTPS.",
                evidence=f"Target scheme is '{target['scheme']}'.",
                impact="Traffic including cookies and form submissions can be intercepted or modified in transit.",
                recommendation="Serve the site exclusively over HTTPS and redirect all HTTP traffic.",
                module=self.name,
            )

        try:
            opts = ctx.client.options(url)
            allowed = opts.headers.get("Allow", "") if opts is not None else ""
            result["allowed_methods"] = [m.strip() for m in allowed.split(",") if m.strip()]
        except Exception:
            result["allowed_methods"] = []

        risky_found = [m for m in result["allowed_methods"] if m in RISKY_METHODS]
        if risky_found:
            ctx.collector.add(
                title="Potentially Risky HTTP Methods Enabled",
                category="HTTP",
                severity="LOW",
                confidence="MEDIUM",
                url=url,
                method="OPTIONS",
                description=f"The server advertises support for: {', '.join(risky_found)}.",
                evidence=f"Allow header: {result['allowed_methods']}",
                impact="Depending on server configuration, these methods can expose write/debug functionality.",
                recommendation="Disable HTTP methods that are not required by the application.",
                module=self.name,
            )

        try:
            baseline = ctx.shared.get("baseline_response") or ctx.client.get(url)
            result["server_header"] = baseline.headers.get("Server", "")
            result["powered_by"] = baseline.headers.get("X-Powered-By", "")
            result["status_code"] = baseline.status_code
        except Exception:
            result["server_header"] = ""
            result["powered_by"] = ""
            result["status_code"] = None

        ctx.shared["http"] = result
