from modules.base import ScanModule, get_baseline_response
from utils.sanitizer import redact_value

SENSITIVE_NAME_HINTS = ("session", "auth", "token", "sid", "jwt", "login")


class CookiesModule(ScanModule):
    name = "Cookie Security"
    category = "cookies"
    description = "Checks Secure/HttpOnly/SameSite flags and scope on every observed cookie."
    safe = True

    def scan(self, ctx):
        url = ctx.target["url"]
        resp = get_baseline_response(ctx)
        if resp is None:
            return
        jar = resp.cookies
        observed = []

        for cookie in jar:
            is_sensitive = any(hint in cookie.name.lower() for hint in SENSITIVE_NAME_HINTS)
            same_site = cookie._rest.get("SameSite") or cookie._rest.get("samesite")
            entry = {
                "name": cookie.name,
                "value": redact_value(cookie.value),
                "secure": bool(cookie.secure),
                "http_only": "HttpOnly" in cookie._rest or "httponly" in cookie._rest,
                "same_site": same_site,
                "domain": cookie.domain,
                "path": cookie.path,
                "expires": cookie.expires,
                "sensitive_name": is_sensitive,
            }
            observed.append(entry)

            if is_sensitive and not entry["secure"] and ctx.target["scheme"] == "https":
                ctx.collector.add(
                    title="Sensitive Cookie Missing Secure Flag",
                    category="Cookies",
                    severity="HIGH",
                    confidence="CONFIRMED",
                    url=url,
                    description=f"Cookie '{cookie.name}' looks session/auth-related but lacks the Secure flag.",
                    evidence=f"Set-Cookie name={cookie.name}, secure={entry['secure']}",
                    impact="The cookie could be sent over an unencrypted connection and intercepted.",
                    recommendation="Add the Secure attribute to all session/authentication cookies.",
                    module=self.name,
                )

            if is_sensitive and not entry["http_only"]:
                ctx.collector.add(
                    title="Sensitive Cookie Missing HttpOnly Flag",
                    category="Cookies",
                    severity="MEDIUM",
                    confidence="CONFIRMED",
                    url=url,
                    description=f"Cookie '{cookie.name}' is readable from JavaScript.",
                    evidence=f"Set-Cookie name={cookie.name}, httponly={entry['http_only']}",
                    impact="An XSS bug would be able to steal this cookie directly.",
                    recommendation="Add the HttpOnly attribute to session/authentication cookies.",
                    module=self.name,
                )

            if not same_site:
                ctx.collector.add(
                    title="Cookie Missing SameSite Attribute",
                    category="Cookies",
                    severity="LOW",
                    confidence="CONFIRMED",
                    url=url,
                    description=f"Cookie '{cookie.name}' does not set SameSite.",
                    evidence=f"Set-Cookie name={cookie.name}",
                    impact="Increases exposure to cross-site request forgery in some browsers.",
                    recommendation="Set SameSite=Lax or Strict unless cross-site delivery is required.",
                    module=self.name,
                )
            elif same_site.lower() == "none" and not entry["secure"]:
                ctx.collector.add(
                    title="SameSite=None Cookie Without Secure",
                    category="Cookies",
                    severity="MEDIUM",
                    confidence="CONFIRMED",
                    url=url,
                    description=f"Cookie '{cookie.name}' sets SameSite=None without Secure.",
                    evidence=f"Set-Cookie name={cookie.name}, SameSite=None, secure={entry['secure']}",
                    impact="Modern browsers reject SameSite=None cookies without Secure, breaking functionality, and it weakens cross-site protection.",
                    recommendation="Pair SameSite=None with the Secure attribute.",
                    module=self.name,
                )

        ctx.shared["cookies"] = observed
