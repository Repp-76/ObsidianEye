from urllib.parse import urlparse
import socket

from modules.base import ScanModule


class ReconModule(ScanModule):
    name = "Reconnaissance"
    category = "reconnaissance"
    description = "Basic target identification: scheme, port, resolved IPs."
    safe = True

    def scan(self, ctx):
        target = ctx.target
        info = dict(target)
        try:
            info["resolved_ips"] = sorted({
                r[4][0] for r in socket.getaddrinfo(target["hostname"], None)
            })
        except (socket.gaierror, OSError, UnicodeError):
            info["resolved_ips"] = []

        try:
            resp = ctx.client.get(target["url"])
            info["final_url"] = resp.url
            info["redirected"] = resp.url != target["url"]
            info["status_code"] = resp.status_code
            ctx.shared["baseline_response"] = resp
        except Exception:
            info["final_url"] = target["url"]
            info["redirected"] = False
            info["status_code"] = None

        ctx.shared["reconnaissance"] = info
        return []
