from urllib.parse import urlparse, parse_qs
from modules.base import ScanModule

PATH_PARAM_HINTS = ("file", "path", "page", "doc", "template", "include", "folder", "dir")


class TraversalModule(ScanModule):
    name = "Path Traversal Indicator Audit"
    category = "traversal"
    description = "Flags file/path-like parameters and checks a harmless traversal probe for signs of file access."
    safe = True

    def scan(self, ctx):
        candidates = []
        for url in ctx.shared.get("endpoints", []):
            qs = parse_qs(urlparse(url).query)
            for name, values in qs.items():
                if any(hint in name.lower() for hint in PATH_PARAM_HINTS):
                    candidates.append((url, name, values[0] if values else ""))

        for url, param, original in candidates[:5]:
            probe_url = url.replace(f"{param}={original}", f"{param}=..%2f..%2f..%2fobsidianeye_probe")
            try:
                resp = ctx.client.get(probe_url)
            except Exception:
                continue
            if resp is not None and resp.status_code == 200 and "obsidianeye_probe" not in (resp.text or ""):
                # server accepted a traversal-shaped path without erroring — worth a look, not proof
                ctx.collector.add(
                    title="File Parameter Accepts Traversal-Shaped Input",
                    category="Path Traversal",
                    severity="MEDIUM",
                    confidence="POTENTIAL",
                    url=probe_url,
                    parameter=param,
                    description=f"Parameter '{param}' returned HTTP 200 for a traversal-shaped value instead of erroring.",
                    evidence=f"Probe path segment: ../../../obsidianeye_probe",
                    impact="If the parameter maps to filesystem paths without validation, arbitrary file read may be possible.",
                    recommendation="Resolve and validate the final path stays within an intended base directory before use.",
                    module=self.name,
                )
