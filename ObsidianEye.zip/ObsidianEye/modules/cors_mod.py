from modules.base import ScanModule

PROBE_ORIGIN = "https://obsidianeye-cors-probe.invalid"


class CorsModule(ScanModule):
    name = "CORS Configuration"
    category = "cors"
    description = "Sends a foreign Origin header and inspects how CORS responds."
    safe = True

    def scan(self, ctx):
        url = ctx.target["url"]
        try:
            resp = ctx.client.get(url, headers={"Origin": PROBE_ORIGIN})
        except Exception:
            return

        acao = resp.headers.get("Access-Control-Allow-Origin")
        acac = resp.headers.get("Access-Control-Allow-Credentials", "").lower() == "true"
        ctx.shared["cors"] = {"allow_origin": acao, "allow_credentials": acac}

        if acao == "*" and acac:
            ctx.collector.add(
                title="CORS Wildcard Origin With Credentials",
                category="CORS",
                severity="CRITICAL",
                confidence="CONFIRMED",
                url=url,
                description="Access-Control-Allow-Origin is '*' while credentials are allowed.",
                evidence=f"ACAO=*, ACAC={acac}",
                impact="Browsers block this combination, but it signals a broken CORS policy that likely reflects origins elsewhere.",
                recommendation="Never combine a wildcard origin with Allow-Credentials: true.",
                module=self.name,
            )
        elif acao == PROBE_ORIGIN:
            ctx.collector.add(
                title="CORS Reflects Arbitrary Origin",
                category="CORS",
                severity="HIGH" if acac else "MEDIUM",
                confidence="CONFIRMED",
                url=url,
                description="The server reflected an unrecognized, attacker-controlled Origin header back in ACAO.",
                evidence=f"Sent Origin={PROBE_ORIGIN}, received ACAO={acao}, credentials={acac}",
                impact="Any website can read responses from this endpoint on behalf of a visiting user" + (
                    ", including authenticated data." if acac else "."
                ),
                recommendation="Validate Origin against an explicit allowlist instead of reflecting it.",
                module=self.name,
            )
        elif acao == "null":
            ctx.collector.add(
                title="CORS Allows 'null' Origin",
                category="CORS",
                severity="MEDIUM",
                confidence="CONFIRMED",
                url=url,
                description="Access-Control-Allow-Origin is set to 'null'.",
                evidence="ACAO: null",
                impact="Sandboxed iframes and some local-file contexts send Origin: null and would be trusted.",
                recommendation="Remove 'null' from the set of allowed CORS origins.",
                module=self.name,
            )
