from modules.base import ScanModule

CANDIDATE_DIRS = ("/uploads/", "/files/", "/backup/", "/static/", "/assets/", "/images/", "/logs/", "/tmp/")
LISTING_MARKERS = ("Index of /", "<title>Directory listing for", "Parent Directory</a>")


class DirectoryListingModule(ScanModule):
    name = "Directory Listing"
    category = "files"
    description = "Requests common directories and checks for autoindex-style listing output."
    safe = True

    def scan(self, ctx):
        base = ctx.target["url"]
        for path in CANDIDATE_DIRS:
            url = base + path
            try:
                resp = ctx.client.get(url)
            except Exception:
                continue
            if resp is not None and resp.status_code == 200 and any(m in (resp.text or "") for m in LISTING_MARKERS):
                ctx.collector.add(
                    title="Directory Listing Enabled",
                    category="File Exposure",
                    severity="MEDIUM",
                    confidence="CONFIRMED",
                    url=url,
                    description=f"Directory index/autoindex output was returned for {path}.",
                    evidence="Response body matches known directory-listing markup.",
                    impact="Attackers can enumerate every file in the directory, including unlinked/forgotten ones.",
                    recommendation="Disable directory autoindexing on the web server.",
                    module=self.name,
                )
