from dataclasses import dataclass, field


@dataclass
class ScanContext:
    client: object
    target: dict           # {url, hostname, scheme, port}
    collector: object       # FindingCollector
    shared: dict = field(default_factory=dict)  # cross-module scratch space


def get_baseline_response(ctx):
    """Cached first successful GET of the target root, shared across
    modules so the same request isn't repeated. Never raises — a target
    that can't be reached just yields None, and callers are expected to
    skip gracefully rather than let the exception kill the whole module."""
    if "baseline_response" in ctx.shared:
        return ctx.shared["baseline_response"]
    try:
        resp = ctx.client.get(ctx.target["url"])
    except Exception:
        resp = None
    ctx.shared["baseline_response"] = resp
    return resp


class ScanModule:
    name = "unnamed"
    category = "uncategorized"
    description = ""
    version = "1.0"
    safe = True

    def scan(self, ctx: ScanContext):
        raise NotImplementedError
