from dataclasses import dataclass, field


@dataclass
class ScanContext:
    client: object
    target: dict           # {url, hostname, scheme, port}
    collector: object       # FindingCollector
    shared: dict = field(default_factory=dict)  # cross-module scratch space


class ScanModule:
    name = "unnamed"
    category = "uncategorized"
    description = ""
    version = "1.0"
    safe = True

    def scan(self, ctx: ScanContext):
        raise NotImplementedError
