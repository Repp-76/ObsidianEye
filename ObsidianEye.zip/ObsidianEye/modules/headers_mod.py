import re
from modules.base import ScanModule, get_baseline_response


class HeadersModule(ScanModule):
    name = "Security Headers"
    category = "headers"
    description = "Deep inspection of security-relevant response headers, not just presence."
    safe = True

    def scan(self, ctx):
        url = ctx.target["url"]
        resp = get_baseline_response(ctx)
        if resp is None:
            return
        headers = {k: v for k, v in resp.headers.items()}
        ctx.shared["headers"] = headers

        if "Strict-Transport-Security" not in headers:
            if ctx.target["scheme"] == "https":
                ctx.collector.add(
                    title="Missing HSTS Header",
                    category="Headers",
                    severity="MEDIUM",
                    confidence="CONFIRMED",
                    url=url,
                    description="No Strict-Transport-Security header was returned.",
                    evidence="HSTS header absent from response.",
                    impact="Users can be downgraded to HTTP by an attacker on the network path.",
                    recommendation="Send 'Strict-Transport-Security: max-age=31536000; includeSubDomains'.",
                    module=self.name,
                )
        else:
            hsts = headers["Strict-Transport-Security"]
            max_age_match = re.search(r"max-age=(\d+)", hsts)
            max_age = int(max_age_match.group(1)) if max_age_match else 0
            if max_age < 15552000:  # 180 days
                ctx.collector.add(
                    title="Weak HSTS max-age",
                    category="Headers",
                    severity="LOW",
                    confidence="CONFIRMED",
                    url=url,
                    description=f"HSTS max-age is only {max_age} seconds.",
                    evidence=hsts,
                    impact="A short max-age gives attackers a window to strip HSTS protection.",
                    recommendation="Set max-age to at least 15552000 (180 days), ideally 31536000 with preload.",
                    module=self.name,
                )
            if "includeSubDomains" not in hsts:
                ctx.collector.add(
                    title="HSTS Missing includeSubDomains",
                    category="Headers",
                    severity="LOW",
                    confidence="CONFIRMED",
                    url=url,
                    description="HSTS header does not set includeSubDomains.",
                    evidence=hsts,
                    impact="Subdomains remain vulnerable to protocol downgrade attacks.",
                    recommendation="Add includeSubDomains to the HSTS header if all subdomains support HTTPS.",
                    module=self.name,
                )

        csp = headers.get("Content-Security-Policy")
        if not csp:
            ctx.collector.add(
                title="Missing Content-Security-Policy",
                category="Headers",
                severity="MEDIUM",
                confidence="CONFIRMED",
                url=url,
                description="No Content-Security-Policy header was found.",
                evidence="CSP header absent.",
                impact="Reduces defense-in-depth against XSS and data injection attacks.",
                recommendation="Define a CSP restricting script/style/object sources.",
                module=self.name,
            )
        else:
            if "unsafe-inline" in csp or "unsafe-eval" in csp:
                ctx.collector.add(
                    title="Weak Content-Security-Policy",
                    category="Headers",
                    severity="MEDIUM",
                    confidence="CONFIRMED",
                    url=url,
                    description="CSP allows 'unsafe-inline' and/or 'unsafe-eval'.",
                    evidence=csp,
                    impact="These directives largely defeat CSP's protection against script injection.",
                    recommendation="Remove unsafe-inline/unsafe-eval; use nonces or hashes for required inline scripts.",
                    module=self.name,
                )
            if re.search(r"script-src[^;]*\*", csp):
                ctx.collector.add(
                    title="Wildcard Script Source in CSP",
                    category="Headers",
                    severity="MEDIUM",
                    confidence="CONFIRMED",
                    url=url,
                    description="CSP script-src directive includes a wildcard source.",
                    evidence=csp,
                    impact="Any origin can serve scripts into the page, defeating the purpose of CSP.",
                    recommendation="Restrict script-src to an explicit allowlist of trusted origins.",
                    module=self.name,
                )

        if "X-Frame-Options" not in headers and "frame-ancestors" not in (csp or ""):
            ctx.collector.add(
                title="Missing Clickjacking Protection",
                category="Headers",
                severity="MEDIUM",
                confidence="CONFIRMED",
                url=url,
                description="Neither X-Frame-Options nor CSP frame-ancestors is set.",
                evidence="Both protections absent.",
                impact="The page can potentially be framed by a malicious site for clickjacking.",
                recommendation="Set X-Frame-Options: DENY or SAMEORIGIN, or CSP frame-ancestors.",
                module=self.name,
            )

        if "X-Content-Type-Options" not in headers:
            ctx.collector.add(
                title="Missing X-Content-Type-Options",
                category="Headers",
                severity="LOW",
                confidence="CONFIRMED",
                url=url,
                description="X-Content-Type-Options header is not set to nosniff.",
                evidence="Header absent.",
                impact="Browsers may MIME-sniff responses, enabling certain content-type confusion attacks.",
                recommendation="Set 'X-Content-Type-Options: nosniff'.",
                module=self.name,
            )

        ref_policy = headers.get("Referrer-Policy", "")
        if not ref_policy or ref_policy.lower() in ("unsafe-url",):
            ctx.collector.add(
                title="Weak or Missing Referrer-Policy",
                category="Headers",
                severity="LOW",
                confidence="CONFIRMED",
                url=url,
                description="Referrer-Policy is missing or set to an overly permissive value.",
                evidence=f"Referrer-Policy: {ref_policy or '(absent)'}",
                impact="Full URLs, potentially including sensitive query parameters, may leak to third parties.",
                recommendation="Set Referrer-Policy to 'strict-origin-when-cross-origin' or stricter.",
                module=self.name,
            )

        if "Permissions-Policy" not in headers:
            ctx.collector.add(
                title="Missing Permissions-Policy",
                category="Headers",
                severity="INFO",
                confidence="CONFIRMED",
                url=url,
                description="No Permissions-Policy header restricting browser features was found.",
                evidence="Header absent.",
                impact="Powerful browser APIs (camera, geolocation, etc.) are not explicitly restricted.",
                recommendation="Add a Permissions-Policy header scoped to features actually used.",
                module=self.name,
            )

        for header, label in (
            ("Cross-Origin-Opener-Policy", "COOP"),
            ("Cross-Origin-Embedder-Policy", "COEP"),
            ("Cross-Origin-Resource-Policy", "CORP"),
        ):
            if header not in headers:
                ctx.collector.add(
                    title=f"Missing {label} Header",
                    category="Headers",
                    severity="INFO",
                    confidence="CONFIRMED",
                    url=url,
                    description=f"{header} is not set.",
                    evidence="Header absent.",
                    impact=f"Reduces isolation guarantees {label} normally provides against cross-origin attacks.",
                    recommendation=f"Set {header} appropriately for the application's isolation needs.",
                    module=self.name,
                )
