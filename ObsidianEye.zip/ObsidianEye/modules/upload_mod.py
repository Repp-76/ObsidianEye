from modules.base import ScanModule


class UploadSecurityModule(ScanModule):
    name = "File Upload Security"
    category = "uploads"
    description = "Identifies upload forms and reports observable client-side restrictions. Never uploads files."
    safe = True

    def scan(self, ctx):
        forms = ctx.shared.get("forms", [])
        upload_forms = [f for f in forms if any((i["type"] or "").lower() == "file" for i in f["inputs"])]
        if not upload_forms:
            return

        ctx.shared["upload_forms"] = upload_forms
        form = upload_forms[0]
        file_field = next(i for i in form["inputs"] if (i["type"] or "").lower() == "file")
        accept = file_field.get("accept", "") if isinstance(file_field, dict) else ""

        ctx.collector.add(
            title="Upload Functionality Present",
            category="File Upload",
            severity="INFO",
            confidence="CONFIRMED",
            url=form["page"],
            method=form["method"],
            description=f"An upload form was found at {form['page']}. No file was uploaded by this scan.",
            evidence=f"action={form['action']}, client-side accept='{accept or '(none)'}'",
            impact="Manual review recommended: verify server-side extension/MIME validation and that upload storage isn't web-executable.",
            recommendation="Validate file type server-side (not just client-side accept=), store uploads outside the webroot or with execution disabled, and enforce size limits.",
            module=self.name,
        )

        if not accept:
            ctx.collector.add(
                title="Upload Form Has No Client-Side Type Restriction",
                category="File Upload",
                severity="LOW",
                confidence="CONFIRMED",
                url=form["page"],
                description="The file input has no 'accept' attribute restricting file types.",
                evidence="input[type=file] has no accept attribute",
                impact="Not a vulnerability by itself (server-side validation is what matters), but worth confirming server-side checks exist.",
                recommendation="Confirm the server enforces its own extension/MIME/content validation regardless of client hints.",
                module=self.name,
            )
