from modules.base import ScanModule


class DosProtectionModule(ScanModule):
    name = "Availability / Rate-Limit Protection Audit"
    category = "dos_protection"
    description = "Does NOT perform a DoS. Looks at headers/behavior for rate-limiting, WAF and CDN indicators."
    safe = True

    def scan(self, ctx):
        headers = ctx.shared.get("headers", {})
        rate_limit_headers = [h for h in headers if h.lower().startswith(("x-ratelimit", "ratelimit"))]
        waf_hits = [t["technology"] for t in ctx.shared.get("technologies", []) if t["category"] == "cdn_waf"]

        statuses = []
        try:
            for _ in range(6):
                resp = ctx.client.get(ctx.target["url"])
                if resp is not None:
                    statuses.append(resp.status_code)
        except Exception:
            pass
        throttled = any(s == 429 for s in statuses)

        ctx.shared["dos_audit"] = {
            "rate_limit_headers": rate_limit_headers,
            "waf_or_cdn": waf_hits,
            "throttled_during_probe": throttled,
        }

        if not rate_limit_headers and not waf_hits and not throttled:
            ctx.collector.add(
                title="No Rate-Limiting Indicators",
                category="Availability",
                severity="LOW",
                confidence="LOW",
                url=ctx.target["url"],
                description="No rate-limit headers, WAF/CDN fingerprint, or 429 throttling were observed during a handful of requests.",
                evidence=f"statuses={statuses}, rate_limit_headers={rate_limit_headers}, waf/cdn={waf_hits}",
                impact="This is a weak signal, not proof — many stacks throttle upstream without exposing headers. Still worth reviewing.",
                recommendation="Confirm rate limiting exists somewhere in the stack (app, gateway, CDN) for public endpoints.",
                module=self.name,
            )
