from modules.base import ScanModule


class SecurityTxtModule(ScanModule):
    name = "security.txt"
    category = "configuration"
    description = "Checks for /.well-known/security.txt and validates its expected fields."
    safe = True

    def scan(self, ctx):
        url = ctx.target["url"] + "/.well-known/security.txt"
        try:
            resp = ctx.client.get(url)
        except Exception:
            return
        if resp is None or resp.status_code != 200:
            ctx.collector.add(
                title="Missing security.txt",
                category="Configuration",
                severity="INFO",
                confidence="CONFIRMED",
                url=url,
                description="No /.well-known/security.txt was found.",
                evidence=f"status={resp.status_code if resp is not None else 'no response'}",
                impact="Security researchers have no standard way to report vulnerabilities responsibly.",
                recommendation="Publish a security.txt per RFC 9116 with a Contact and Expires field.",
                module=self.name,
            )
            return

        body = resp.text or ""
        missing = [f for f in ("Contact", "Expires") if f not in body]
        if missing:
            ctx.collector.add(
                title="Incomplete security.txt",
                category="Configuration",
                severity="INFO",
                confidence="CONFIRMED",
                url=url,
                description=f"security.txt is missing recommended field(s): {', '.join(missing)}.",
                evidence=body[:200],
                impact="Missing Contact/Expires reduces how useful the file is for researchers.",
                recommendation="Include Contact and Expires fields per RFC 9116.",
                module=self.name,
            )
