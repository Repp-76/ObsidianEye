from urllib.parse import urlparse, parse_qs
from modules.base import ScanModule

URL_PARAM_HINTS = ("url", "uri", "path", "dest", "callback", "webhook", "src", "image", "feed", "link", "target")


class SsrfModule(ScanModule):
    name = "SSRF Indicator Audit"
    category = "ssrf"
    description = "Flags parameters that appear to accept a remote URL, without probing internal infrastructure."
    safe = True

    def scan(self, ctx):
        flagged = []
        for url in ctx.shared.get("endpoints", []):
            qs = parse_qs(urlparse(url).query)
            for name in qs:
                if any(hint in name.lower() for hint in URL_PARAM_HINTS):
                    flagged.append((url, name))

        for form in ctx.shared.get("forms", []):
            for field in form["inputs"]:
                if any(hint in (field["name"] or "").lower() for hint in URL_PARAM_HINTS):
                    flagged.append((form["page"], field["name"]))

        if flagged:
            url, param = flagged[0]
            ctx.collector.add(
                title="Parameter Accepting a Remote URL",
                category="SSRF",
                severity="LOW",
                confidence="POTENTIAL",
                url=url,
                parameter=param,
                description=(
                    f"{len(flagged)} parameter(s) named like a URL/callback/webhook field were found. "
                    "This is only an indicator; internal/private addresses were not probed."
                ),
                evidence=f"Example: parameter '{param}' on {url}",
                impact="If the server fetches this URL server-side without validation, SSRF against internal services may be possible.",
                recommendation="Validate and allowlist destinations before the server fetches a user-supplied URL; block private IP ranges and metadata endpoints.",
                module=self.name,
            )
