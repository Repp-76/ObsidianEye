import re
from modules.base import ScanModule
from utils.sanitizer import find_secret_hits

ENDPOINT_RE = re.compile(r"""["'](/[a-zA-Z0-9_\-./]{2,80})["']""")
SOURCEMAP_RE = re.compile(r"//#\s*sourceMappingURL=(.+\.map)")


class JavaScriptModule(ScanModule):
    name = "JavaScript Analysis"
    category = "javascript"
    description = "Pulls endpoint paths, source-map references and possible secret patterns out of client-side JS."
    safe = True

    def scan(self, ctx):
        scripts = ctx.shared.get("scripts", [])[:25]  # cap for a reasonable scan time
        discovered_paths = set()
        secret_hits = []
        sourcemaps = []

        for script_url in scripts:
            try:
                resp = ctx.client.get(script_url)
            except Exception:
                continue
            if resp is None:
                continue
            body = resp.text or ""

            discovered_paths.update(m for m in ENDPOINT_RE.findall(body) if not m.endswith((".png", ".jpg", ".css")))
            secret_hits.extend(find_secret_hits(body))

            sm_match = SOURCEMAP_RE.search(body)
            if sm_match:
                sourcemaps.append((script_url, sm_match.group(1)))

        ctx.shared["js_discovered_paths"] = sorted(discovered_paths)

        if secret_hits:
            ctx.collector.add(
                title="Possible Secret Pattern in Client-Side JavaScript",
                category="JavaScript",
                severity="HIGH",
                confidence="MEDIUM",
                url=scripts[0] if scripts else ctx.target["url"],
                description=f"{len(secret_hits)} value(s) matching known API-key/token patterns were found in shipped JavaScript.",
                evidence=f"Redacted matches: {secret_hits[:5]}",
                impact="Secrets shipped to the browser are visible to every visitor and cannot be considered confidential.",
                recommendation="Move secrets server-side; rotate anything that may already be exposed.",
                module=self.name,
            )

        if sourcemaps:
            ctx.collector.add(
                title="Exposed Source Map",
                category="JavaScript",
                severity="LOW",
                confidence="HIGH",
                url=sourcemaps[0][0],
                description=f"{len(sourcemaps)} script(s) reference a publicly accessible source map.",
                evidence=f"Example: {sourcemaps[0][1]}",
                impact="Source maps can reveal original, unminified source code and internal structure.",
                recommendation="Exclude source maps from production deployments or restrict access to them.",
                module=self.name,
            )
