from modules.base import ScanModule


class BruteForceProtectionModule(ScanModule):
    name = "Brute-Force Protection Audit"
    category = "brute_force_protection"
    description = (
        "Does NOT attempt to brute force any account. Looks at a handful of login "
        "attempts for rate-limit/lockout/CAPTCHA indicators only."
    )
    safe = True

    def scan(self, ctx):
        login_forms = ctx.shared.get("login_forms", [])
        if not login_forms:
            return
        form = login_forms[0]
        pw_field = next((i["name"] for i in form["inputs"] if (i["type"] or "").lower() == "password"), None)
        user_field = next((i["name"] for i in form["inputs"] if "user" in (i["name"] or "").lower() or "email" in (i["name"] or "").lower()), None)
        if not (pw_field and user_field):
            return

        captcha_present = any(
            "captcha" in (i["name"] or "").lower() or "captcha" in (i["type"] or "").lower()
            for i in form["inputs"]
        )

        statuses = []
        try:
            # A small, fixed number of attempts (5) is enough to see whether the
            # server starts throttling — this is an audit of the control, not an attack.
            for i in range(5):
                resp = ctx.client.post(form["action"], data={user_field: "obsidianeye_probe", pw_field: f"wrong{i}"})
                statuses.append(resp.status_code if resp is not None else None)
        except Exception:
            pass

        throttled = any(s == 429 for s in statuses)
        ctx.shared["bruteforce_audit"] = {
            "captcha_present": captcha_present,
            "observed_statuses": statuses,
            "throttling_observed": throttled,
        }

        if not throttled and not captcha_present:
            ctx.collector.add(
                title="No Brute-Force Protection Indicators",
                category="Brute-Force Protection",
                severity="MEDIUM",
                confidence="LOW",
                url=form["action"],
                method="POST",
                description=(
                    "Five quick login attempts produced no 429/throttle response and no CAPTCHA "
                    "field was present. This does not confirm the account can be brute forced — "
                    "protection may exist server-side (WAF, IP-based limits) without a visible signal."
                ),
                evidence=f"statuses observed: {statuses}",
                impact="Without rate limiting or lockout, automated credential attacks become cheaper to run.",
                recommendation="Add progressive delays, account lockout, CAPTCHA after repeated failures, or IP-based throttling.",
                module=self.name,
            )
