from modules.base import ScanModule

SENSITIVE_PATHS = [
    ".git/HEAD", ".git/config", ".env", ".env.local", "config.php.bak",
    "backup.zip", "backup.sql", "database.sql", "wp-config.php.bak",
    ".DS_Store", "web.config", "docker-compose.yml", ".svn/entries",
    "composer.json", "package.json.bak", "id_rsa", ".htpasswd",
]


class SensitiveFilesModule(ScanModule):
    name = "Sensitive File Exposure"
    category = "files"
    description = "Requests a curated list of common sensitive paths and reports exposure without dumping contents."
    safe = True

    def scan(self, ctx):
        base = ctx.target["url"]
        for path in SENSITIVE_PATHS:
            url = f"{base}/{path}"
            try:
                resp = ctx.client.get(url)
            except Exception:
                continue
            if resp is not None and resp.status_code == 200 and len(resp.content) > 0:
                ctx.collector.add(
                    title="Sensitive File Publicly Accessible",
                    category="File Exposure",
                    severity="HIGH" if path.startswith(".git") or path.endswith((".sql", ".env", "id_rsa")) else "MEDIUM",
                    confidence="HIGH",
                    url=url,
                    description=f"'{path}' returned HTTP 200 and appears to be a real file, not a custom 404 page.",
                    evidence=f"status=200, content-length={len(resp.content)}",
                    impact="Depending on the file, this can leak credentials, source code, or infrastructure details.",
                    recommendation=f"Remove or block public access to '{path}'.",
                    module=self.name,
                )
