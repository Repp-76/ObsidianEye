import json
from modules.base import ScanModule

CANDIDATE_PATHS = ("/graphql", "/api/graphql", "/graphql/console", "/v1/graphql")
INTROSPECTION_QUERY = {"query": "{__schema{queryType{name}}}"}


class GraphQLModule(ScanModule):
    name = "GraphQL Security"
    category = "graphql"
    description = "Detects a GraphQL endpoint and checks whether introspection is publicly enabled."
    safe = True

    def scan(self, ctx):
        base = ctx.target["url"]
        for path in CANDIDATE_PATHS:
            url = base + path
            try:
                resp = ctx.client.post(url, json=INTROSPECTION_QUERY, headers={"Content-Type": "application/json"})
            except Exception:
                continue
            if resp is None or resp.status_code >= 400:
                continue
            try:
                data = resp.json()
            except (ValueError, json.JSONDecodeError):
                continue

            ctx.shared.setdefault("apis", []).append(url)
            if isinstance(data, dict) and data.get("data", {}).get("__schema"):
                ctx.collector.add(
                    title="GraphQL Introspection Enabled",
                    category="GraphQL",
                    severity="MEDIUM",
                    confidence="CONFIRMED",
                    url=url,
                    method="POST",
                    description="The GraphQL endpoint answers introspection queries without authentication.",
                    evidence="__schema.queryType returned in response to an unauthenticated introspection query.",
                    impact="Introspection exposes the full schema, making it far easier to find sensitive or unintended fields/mutations.",
                    recommendation="Disable introspection in production or require authentication for it.",
                    module=self.name,
                )
            return
