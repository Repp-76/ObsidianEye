from urllib.parse import urlparse, parse_qs, urlencode
from modules.base import ScanModule

REDIRECT_PARAM_HINTS = ("next", "return", "redirect", "url", "dest", "destination", "continue", "callback")
PROBE_TARGET = "https://obsidianeye-redirect-probe.invalid/"


class OpenRedirectModule(ScanModule):
    name = "Open Redirect Audit"
    category = "redirects"
    description = "Tests redirect-shaped parameters with a harmless external URL and checks if the app follows it."
    safe = True

    def scan(self, ctx):
        candidates = []
        for url in ctx.shared.get("endpoints", []):
            base = urlparse(url)
            qs = parse_qs(base.query)
            for name in qs:
                if any(hint in name.lower() for hint in REDIRECT_PARAM_HINTS):
                    candidates.append((base, name))

        checked = 0
        for base, param in candidates:
            if checked >= 10:
                break
            checked += 1
            probe_qs = parse_qs(base.query)
            probe_qs[param] = [PROBE_TARGET]
            probe_url = base._replace(query=urlencode(probe_qs, doseq=True)).geturl()
            try:
                resp = ctx.client.get(probe_url, allow_redirects=False)
            except Exception:
                continue
            location = resp.headers.get("Location", "") if resp is not None else ""
            if location.startswith(PROBE_TARGET):
                ctx.collector.add(
                    title="Open Redirect",
                    category="Open Redirect",
                    severity="MEDIUM",
                    confidence="HIGH",
                    url=probe_url,
                    parameter=param,
                    description=f"Parameter '{param}' redirected the browser to an arbitrary external URL.",
                    evidence=f"Location header: {location}",
                    impact="Can be used in phishing to make malicious links appear to originate from a trusted domain.",
                    recommendation="Validate redirect targets against an allowlist of internal paths/domains.",
                    module=self.name,
                )
